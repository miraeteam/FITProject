$(document).ready(
		function() {

			$(".member_join_choice ul li").each(
					function() {

						var arrow = $(this).children(".arrow");
						$(this).click(
								function() {
									$(".member_join_choice ul li").children(
											".arrow").not(arrow).hide();
									$(arrow).show();
								});
					});

			$(".common_agree_box ul li .subject .link").click(function() {
				var a_box = $(this).parent().parent().next(".box")
				$(a_box).slideToggle();
			});

		});
