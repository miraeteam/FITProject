var loginUserId = "";
$(function() {
	errCodeCheck();
	emailCheck();

	var message = [ "영문,숫자,특수문자만 가능. 8 ~ 15자 입력해 주세요.",
			"비밀번호와 비밀번호 확인란은 값이 일치해야 합니다." ];
	$('.error').each(function(index) {
		$('.error').eq(index).html(message[index]);
	});

	$('#userPw, #userPwCheck').bind("focus", function() {
		var idx = $("#userPw, #userPwCheck").index(this);
		// console.log("대상 : "+ idx );
		$(this).parents(".form-group").find(".error").html(message[idx]);
	});

	/* 확인 버튼 클릭 시 처리 이벤트 */
	$("#modifyOk").click(
			function() {
				if (passwordCheck() == false) {
					return;
				}

				$("#email").val(
						$("#email").val() + "@" + $("#emailDomain").val());
				$("#address").val(
						$("#sample4_postcode").val() + "/"
								+ $("#sample4_roadAddress").val() + "/"
								+ $("#detailAddress").val());
				// 입력값 체크
				$("#memberForm").attr({
					"method" : "post",
					"action" : "/member/modify.do"
				});
				$("#memberForm").submit();
				alert("수정완료");
			});

	$("#modifyReset").click(function() {
		$("#memberForm").each(function() {
			this.reset();
		});
	});

	$("#modifyCancel").click(function() {
		location.href = "/member/login.do";
	});
});

function passwordCheck() {
	if ($("#userPw").val() != $("#userPwCheck").val()) {
		alert("패스워드 입력이 일치하지 않습니다");
		$("#userPw").val("");
		$("#userPwCheck").val("");
		$("#userPw").focus();
		return false;
	}

}

function idPwdCheck() {
	var userId = loginUserId;
	var userPw = $("#userPw").val();
	if (userPw.indexOf(userId) > -1) {
		alert("비밀번호에 아이디를 포함할 수 없습니다.");
		$("#userPw").val("");
		$("#userPw").focus();
		return false;
	} else {
		return true;
	}
}