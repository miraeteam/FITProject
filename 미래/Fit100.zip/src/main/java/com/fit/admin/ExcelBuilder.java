package com.fit.admin;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.fit.client.hire.vo.HireVO;
import com.fit.client.resume.vo.ResumeVO;

public class ExcelBuilder extends AbstractExcelView {

   protected void buildExcelDocument(Map<String, Object> model, HSSFWorkbook workbook, HttpServletRequest request,
         HttpServletResponse response) throws Exception {
      List<ResumeVO> resumeList = (List<ResumeVO>) model.get("resumeList");
      List<HireVO> hireList = (List<HireVO>) model.get("hireList");

      HSSFSheet sheet = workbook.createSheet("자바책");

      sheet.setDefaultColumnWidth(20);

      CellStyle style = workbook.createCellStyle();

      Font font = workbook.createFont();
      font.setFontName("맑은고딕");

      style.setFillForegroundColor(HSSFColor.GREEN.index);
      style.setFillPattern(CellStyle.SOLID_FOREGROUND);
      font.setBold(true);
      font.setColor(HSSFColor.WHITE.index);
      style.setFont(font);

      int rowCnt = 1;

      HSSFRow title = sheet.createRow(0);
      if (resumeList != null) {

         title.createCell(0).setCellValue("번호");
         title.getCell(0).setCellStyle(style);
         title.createCell(1).setCellValue("학력");
         title.getCell(1).setCellStyle(style);
         title.createCell(2).setCellValue("경력");
         title.getCell(2).setCellStyle(style);
         title.createCell(3).setCellValue("상세경력");
         title.getCell(3).setCellStyle(style);
         title.createCell(4).setCellValue("업종");
         title.getCell(4).setCellStyle(style);
         title.createCell(5).setCellValue("분야");
         title.getCell(5).setCellStyle(style);
         title.createCell(6).setCellValue("근무형태");
         title.getCell(6).setCellStyle(style);
         title.createCell(7).setCellValue("급여");
         title.getCell(7).setCellStyle(style);
         title.createCell(8).setCellValue("지역");
         title.getCell(8).setCellStyle(style);
         title.createCell(9).setCellValue("이력서 제목");
         title.getCell(9).setCellStyle(style);
         title.createCell(10).setCellValue("자기소개");
         title.getCell(10).setCellStyle(style);
         title.createCell(11).setCellValue("이력서 등록일");
         title.getCell(11).setCellStyle(style);

         for (ResumeVO resume : resumeList) {
            HSSFRow row = sheet.createRow(rowCnt++);
            row.createCell(0).setCellValue(resume.getR_num());
            row.createCell(1).setCellValue(resume.getR_level());
            row.createCell(2).setCellValue(resume.getR_career());
            row.createCell(3).setCellValue(resume.getR_detail());
            row.createCell(4).setCellValue(resume.getR_choice());
            row.createCell(5).setCellValue(resume.getR_major());
            row.createCell(6).setCellValue(resume.getR_workType());
            row.createCell(7).setCellValue(resume.getR_salary());
            row.createCell(8).setCellValue(resume.getR_location());
            row.createCell(9).setCellValue(resume.getR_title());
            row.createCell(10).setCellValue(resume.getR_selfInfo());
            row.createCell(11).setCellValue(resume.getR_joinDate());

         }
      }

      if (hireList != null) {

         title.createCell(0).setCellValue("번호");
         title.getCell(0).setCellStyle(style);
         title.createCell(1).setCellValue("업종");
         title.getCell(1).setCellStyle(style);
         title.createCell(2).setCellValue("분야");
         title.getCell(2).setCellStyle(style);
         title.createCell(3).setCellValue("급여");
         title.getCell(3).setCellStyle(style);
         title.createCell(4).setCellValue("지역");
         title.getCell(4).setCellStyle(style);
         title.createCell(5).setCellValue("경력");
         title.getCell(5).setCellStyle(style);
         title.createCell(6).setCellValue("성별");
         title.getCell(6).setCellStyle(style);
         title.createCell(7).setCellValue("근무형태");
         title.getCell(7).setCellStyle(style);
         title.createCell(8).setCellValue("4대보험");
         title.getCell(8).setCellStyle(style);
         title.createCell(9).setCellValue("채용공고 제목");
         title.getCell(9).setCellStyle(style);
         title.createCell(10).setCellValue("채용공고 상세정보");
         title.getCell(10).setCellStyle(style);
         title.createCell(11).setCellValue("접수방법");
         title.getCell(11).setCellStyle(style);
         title.createCell(12).setCellValue("등록일");
         title.getCell(12).setCellStyle(style);
         title.createCell(13).setCellValue("마감일");
         title.getCell(13).setCellStyle(style);
         title.createCell(14).setCellValue("모집인원");
         title.getCell(14).setCellStyle(style);
         title.createCell(15).setCellValue("근무일");
         title.getCell(15).setCellStyle(style);

         for (HireVO hire : hireList) {
            HSSFRow row = sheet.createRow(rowCnt++);
            row.createCell(0).setCellValue(hire.getH_num());
            row.createCell(1).setCellValue(hire.getH_choice());
            row.createCell(2).setCellValue(hire.getH_major());
            row.createCell(3).setCellValue(hire.getH_salary());
            row.createCell(4).setCellValue(hire.getH_location());
            row.createCell(5).setCellValue(hire.getH_career());
            row.createCell(6).setCellValue(hire.getH_gender());
            row.createCell(7).setCellValue(hire.getH_workType());
            row.createCell(8).setCellValue(hire.getH_insurance());
            row.createCell(9).setCellValue(hire.getH_title());
            row.createCell(10).setCellValue(hire.getH_hiredetail());
            row.createCell(11).setCellValue(hire.getH_accept());
            row.createCell(12).setCellValue(hire.getH_insertdate());
            row.createCell(13).setCellValue(hire.getH_deadLine());
            row.createCell(14).setCellValue(hire.getH_count());
            row.createCell(15).setCellValue(hire.getH_workDay());
         }
      }

   }
}