package com.fit.admin.chart.dao;

import java.util.List;

import com.fit.admin.chart.vo.AdminChartVO;
import com.fit.admin.chart.vo.ChartVO;
import com.fit.admin.chart.vo.CompanyChartVO;
import com.fit.admin.chart.vo.MemberChartVO;
import com.fit.common.vo.ComeOnCompanyVO;
import com.fit.common.vo.EmailVO;
import com.fit.common.vo.InterviewApplyVO;
import com.fit.common.vo.OnlineVO;

public interface ChartDAO {
	
	public ChartVO chartView(ChartVO chvo);
	public MemberChartVO memberchartView(MemberChartVO mcvo);
	public CompanyChartVO companychartView(CompanyChartVO ccvo);
	public AdminChartVO adminchartView(AdminChartVO acvo);
	public List<OnlineVO> adminonlineList(OnlineVO ovo);
	public List<EmailVO> adminemailList(EmailVO evo);
	public List<InterviewApplyVO> admininterList(InterviewApplyVO ivo);
	public List<ComeOnCompanyVO> admincomeonList(ComeOnCompanyVO cvo);
}