package com.fit.admin.qna.vo;

import java.util.Date;

import com.fit.client.login.vo.LoginVO;

public class AdminQnaVO extends LoginVO{
	private int Q_num;
	private String Q_title;
	private String Q_content;
	private String whichmember;
	private Date Q_date;
	private String Q_email;
	private String Q_secret;
	private String Q_link;
	private String Q_answer;

	public int getQ_num() {
		return Q_num;
	}

	public void setQ_num(int q_num) {
		Q_num = q_num;
	}

	public String getQ_title() {
		return Q_title;
	}

	public void setQ_title(String q_title) {
		Q_title = q_title;
	}

	public String getQ_content() {
		return Q_content;
	}

	public void setQ_content(String q_content) {
		Q_content = q_content;
	}

	public String getWhichmember() {
		return whichmember;
	}

	public void setWhichmember(String whichmember) {
		this.whichmember = whichmember;
	}

	public Date getQ_date() {
		return Q_date;
	}

	public void setQ_date(Date q_date) {
		Q_date = q_date;
	}

	public String getQ_email() {
		return Q_email;
	}

	public void setQ_email(String q_email) {
		Q_email = q_email;
	}

	public String getQ_secret() {
		return Q_secret;
	}

	public void setQ_secret(String q_secret) {
		Q_secret = q_secret;
	}

	public String getQ_link() {
		return Q_link;
	}

	public void setQ_link(String q_link) {
		Q_link = q_link;
	}

	public String getQ_answer() {
		return Q_answer;
	}

	public void setQ_answer(String q_answer) {
		Q_answer = q_answer;
	}

	@Override
	public String toString() {
		return "QnaVO [Q_num=" + Q_num + ", Q_title=" + Q_title + ", Q_content=" + Q_content + ", whichmember="
				+ whichmember + ", Q_date=" + Q_date + ", Q_email=" + Q_email + ", Q_secret=" + Q_secret + ", Q_link="
				+ Q_link + ", Q_answer=" + Q_answer + "]";
	}

	

	
}
