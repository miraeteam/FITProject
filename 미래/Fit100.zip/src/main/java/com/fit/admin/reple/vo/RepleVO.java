package com.fit.admin.reple.vo;

import java.util.Date;

import com.fit.client.login.vo.LoginVO;

public class RepleVO extends LoginVO{
	private int Re_num;
	private String userId;
	private int Q_num;
	private String Re_content;
	private Date Repledate;
	public int getRe_num() {
		return Re_num;
	}
	public void setRe_num(int re_num) {
		Re_num = re_num;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getQ_num() {
		return Q_num;
	}
	public void setQ_num(int q_num) {
		Q_num = q_num;
	}
	public String getRe_content() {
		return Re_content;
	}
	public void setRe_content(String re_content) {
		Re_content = re_content;
	}
	public Date getRepledate() {
		return Repledate;
	}
	public void setRepledate(Date repledate) {
		Repledate = repledate;
	}
	@Override
	public String toString() {
		return "RepleVO [Re_num=" + Re_num + ", userId=" + userId + ", Q_num=" + Q_num + ", Re_content=" + Re_content
				+ ", Repledate=" + Repledate + "]";
	}
	
	
	
	
}
