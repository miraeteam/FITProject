package com.fit.admin.reple.dao;

import com.fit.admin.reple.vo.RepleVO;

public interface AdminRepleDAO {
	public int insertReple(RepleVO revo);
	public RepleVO repleDetail(RepleVO revo);

}
