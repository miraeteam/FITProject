package com.fit.admin.chart.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fit.admin.chart.vo.AdminChartVO;
import com.fit.admin.chart.vo.ChartVO;
import com.fit.admin.chart.vo.CompanyChartVO;
import com.fit.admin.chart.vo.MemberChartVO;
import com.fit.common.vo.ComeOnCompanyVO;
import com.fit.common.vo.EmailVO;
import com.fit.common.vo.InterviewApplyVO;
import com.fit.common.vo.OnlineVO;

@Repository
@Transactional
public class ChartDAOimpl implements ChartDAO {
	@Autowired
	private SqlSession session;

	// 글상세 구현
	public ChartVO chartView(ChartVO chvo) {
		return (ChartVO) session.selectOne("chartView", chvo);
	}

	public MemberChartVO memberchartView(MemberChartVO mcvo) {
		return (MemberChartVO) session.selectOne("memberchartView", mcvo);
	}

	public CompanyChartVO companychartView(CompanyChartVO ccvo) {
		return (CompanyChartVO) session.selectOne("companychartView", ccvo);
	}
	public AdminChartVO adminchartView(AdminChartVO acvo) {
		return (AdminChartVO) session.selectOne("adminchartView", acvo);
	}
	@Override
	public List<OnlineVO> adminonlineList(OnlineVO ovo) {
		return session.selectList("adminonlineList", ovo);
	}
	@Override
	public List<EmailVO> adminemailList(EmailVO evo) {
		return session.selectList("adminemailList", evo);
	}
	@Override
	public List<InterviewApplyVO> admininterList(InterviewApplyVO ivo) {
		return session.selectList("admininterList", ivo);
	}
	@Override
	public List<ComeOnCompanyVO> admincomeonList(ComeOnCompanyVO cvo) {
		return session.selectList("admincomeonList", cvo);
	}
	
}
