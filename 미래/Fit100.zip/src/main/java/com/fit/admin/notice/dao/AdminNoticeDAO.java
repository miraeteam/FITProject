package com.fit.admin.notice.dao;

import java.util.List;

import com.fit.client.notice.vo.NoticeVO;

public interface AdminNoticeDAO {
	public List<NoticeVO> noticeList();
	public NoticeVO adminnoticeDetail(NoticeVO nvo);
	public int insertNotice(NoticeVO nvo);
}
