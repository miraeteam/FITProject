package com.fit.admin.resume.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fit.client.hire.service.HireService;
import com.fit.client.hire.vo.HireVO;
import com.fit.client.member.vo.MemberVO;
import com.fit.client.resume.service.ResumeService;
import com.fit.client.resume.vo.ResumeVO;
import com.fit.common.page.Paging;

@Controller
@RequestMapping(value = "/admin")
public class AdminResumeController {
	Logger logger = Logger.getLogger(AdminResumeController.class);

	@Autowired
	private ResumeService ResumeService;

	@Autowired
	private HireService hireService;

	

	/* 이력서 리스트 */
	@RequestMapping(value = "/resume/resumeList.do", method = RequestMethod.GET)
	public String resumeList(@ModelAttribute ResumeVO rvo, Model model) {
		logger.info("이력서List ");
		
		Paging.setPage(rvo);
		
		int total = ResumeService.resumeListCnt(rvo);

		List<ResumeVO> resumeList = ResumeService.resumeList(rvo);
		model.addAttribute("resumeList", resumeList);
		model.addAttribute("total", total);
		model.addAttribute("data", rvo);
		return "admin/resume/resumeList";
	}

	/* 내 이력서 리스트 */
	@RequestMapping(value = "/resume/myResumeList.do", method = RequestMethod.GET)
	public String myResumeList(@ModelAttribute ResumeVO rvo, Model model, HttpSession session) {
		logger.info("boardList 호출 성공");

		MemberVO mvo = (MemberVO) session.getAttribute("mvo");
		rvo.setM_num(mvo.getM_num());

		List<ResumeVO> myResumeList = ResumeService.myResumeList(rvo.getM_num());
		model.addAttribute("myResumeList", myResumeList);

		return "admin/resume/myResumeList";
	}

	/* 이력서 상세보기 */
	@RequestMapping(value = "/resume/resumeDetail.do", method = RequestMethod.GET)
	public String resumeDetail(@ModelAttribute ResumeVO rvo, Model model, HttpSession session) {
		logger.info("resumeDetail 호출 성공");
		ResumeVO detail = new ResumeVO();
		detail = ResumeService.resumeDetail(rvo);
		if (detail != null && (!detail.equals(""))) {
			detail.setR_selfInfo(detail.getR_selfInfo().toString().replaceAll("\n", "<br>"));
		}

		int c_num = (int) session.getAttribute("companyNum");

		List<HireVO> myHire = hireService.myHire(c_num);

		model.addAttribute("myHire", myHire);
		model.addAttribute("detail", detail);
		return "admin/resume/resumeDetail";
	}

	// 이력서 등록 폼 보기
	@RequestMapping(value = "/resume/registeForm.do")
	public String registeForm() {
		return "admin/resume/registeForm";
	}

	/**************************************************************
	 * 글쓰기 구현하기
	 **************************************************************/
	@RequestMapping(value = "/resume/resumeInsert.do", method = RequestMethod.POST)
	public String resumeInsert(@ModelAttribute ResumeVO rvo, Model model) throws IllegalStateException, IOException {
		logger.info("목록추가");
		int result = 0;
		String url = "";

		result = ResumeService.resumeInsert(rvo);
		if (result == 1) {
			url = "/admin/resume/resumeList.do";
		} else {
			url = "/admin/resume/registeForm.do";
		}
		return "redirect:" + url;

	}
}
