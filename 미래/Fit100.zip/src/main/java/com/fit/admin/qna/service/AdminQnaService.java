package com.fit.admin.qna.service;

import java.util.List;

import com.fit.client.qna.vo.QnaVO;

public interface AdminQnaService {
	public List<QnaVO>qnaList();
	public int insertQna(QnaVO bvo);
	public QnaVO qnaDetail(QnaVO qnvo);

	public void qnaSelect(int q_num); 
	
	
	
}
