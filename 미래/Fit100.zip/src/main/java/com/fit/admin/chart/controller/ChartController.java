package com.fit.admin.chart.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.fit.admin.chart.service.ChartService;
import com.fit.admin.chart.vo.ChartVO;
import com.fit.admin.chart.vo.CompanyChartVO;
import com.fit.admin.chart.vo.MemberChartVO;
import com.fit.admin.notice.controller.AdminNoticeController;

@Controller
@RequestMapping(value = "/admin")
public class ChartController {
	Logger logger = Logger.getLogger(AdminNoticeController.class);
@Autowired
private ChartService chartservice;  
	
	@RequestMapping(value = "/static/memberchart.do", method = RequestMethod.GET)
	public ModelAndView chart( MemberChartVO mcvo,CompanyChartVO ccvo, ModelAndView model) {
		logger.info("noticeDetail 호출 성공");
	
		MemberChartVO detail = new MemberChartVO();
		detail = chartservice.memberchartView(mcvo);
       model.addObject("memberchart", detail);
		
       CompanyChartVO detailc = new CompanyChartVO();
       detailc = chartservice.companychartView(ccvo);
       model.addObject("companychart", detailc);
       
       
       
       model.setViewName("admin/static/memberchart");
		return model;
	}
	
	@RequestMapping(value = "/static/chartView.do", method = RequestMethod.GET)
	public ModelAndView chart( ChartVO chvo, ModelAndView model) {
		logger.info("noticeDetail 호출 성공");
		ChartVO detail = new ChartVO();
		detail = chartservice.chartView(chvo);
		
		model.addObject("chart", detail);
		model.setViewName("admin/static/piechart");
		return model;
	}
}
