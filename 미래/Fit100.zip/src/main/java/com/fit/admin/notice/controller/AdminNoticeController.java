package com.fit.admin.notice.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fit.admin.notice.service.AdminNoticeService;
import com.fit.client.notice.vo.NoticeVO;

@Controller
@RequestMapping(value = "/admin")
public class AdminNoticeController {
	Logger logger = Logger.getLogger(AdminNoticeController.class);

	@Autowired
	private AdminNoticeService adminNoticeService;

	/**************************************************************
	 * �۸�� �����ϱ�
	 **************************************************************/
	@RequestMapping(value = "/notice/noticeList.do", method = RequestMethod.GET)
	public String anoticeList(@ModelAttribute NoticeVO nvo, Model model) {
		logger.info("adminnoticeList");
	
		List<NoticeVO> noticeList = adminNoticeService.noticeList();
		model.addAttribute("noticeList", noticeList);
		model.addAttribute("data", nvo);
		return "admin/notice/noticeList";
	}
	/*공지사항 상세보기*/
	@RequestMapping(value = "/notice/noticeDetail.do", method = RequestMethod.GET)
	public String anoticeDetail(@ModelAttribute NoticeVO nvo, Model model, HttpSession session) {
		logger.info("noticeDetail 호출 성공");
		NoticeVO detail = new NoticeVO();
		detail = adminNoticeService.adminnoticeDetail(nvo);
		if (detail != null && (!detail.equals(""))) {
			detail.setN_title(detail.getN_title().toString().replaceAll("\n", "<br>"));
		}
		
		model.addAttribute("detail", detail);
		return "admin/notice/noticeDetail";
	}
	@RequestMapping(value = "/notice/insertNotice.do", method = RequestMethod.POST)
	public String aNoticeInsert(@ModelAttribute NoticeVO nvo, Model model) throws IllegalStateException, IOException {
		logger.info("관리자 공지 목록추가");
		int result = 0;
		String url = "";
		
		result = adminNoticeService.insertNotice(nvo);
		if (result == 1) {
			url = "/admin/notice/noticeList.do";
		} else {
			url = "/admin/notice/writenotice.do";
		}
		
		return "redirect:" + url;

	}
	/**************************************************************
	 * 글쓰기 폼 출력하기
	 **************************************************************/
	@RequestMapping(value = "/notice/writenotice.do")
	public String awriteForm() {
		logger.info("noticewriteForm 출력");
		return "admin/notice/writenotice";
	}

	
}
