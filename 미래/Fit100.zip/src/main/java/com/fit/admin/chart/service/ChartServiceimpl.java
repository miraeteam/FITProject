package com.fit.admin.chart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fit.admin.chart.dao.ChartDAO;
import com.fit.admin.chart.vo.AdminChartVO;
import com.fit.admin.chart.vo.ChartVO;
import com.fit.admin.chart.vo.CompanyChartVO;
import com.fit.admin.chart.vo.MemberChartVO;
import com.fit.common.vo.ComeOnCompanyVO;
import com.fit.common.vo.EmailVO;
import com.fit.common.vo.InterviewApplyVO;
import com.fit.common.vo.OnlineVO;
@Service
@Transactional
public class ChartServiceimpl implements ChartService {
	@Autowired
	private ChartDAO chartDAO;

	
	public ChartVO chartView(ChartVO chvo) {
		ChartVO detail = null;
		detail = chartDAO.chartView(chvo);
		return detail;
	}
	public MemberChartVO memberchartView(MemberChartVO mcvo) {
		MemberChartVO detail = null;
		detail = chartDAO.memberchartView(mcvo);
		return detail;
	}
	public CompanyChartVO companychartView(CompanyChartVO ccvo) {
		CompanyChartVO detail = null;
		detail = chartDAO.companychartView(ccvo);
		return detail;
	}
	public AdminChartVO adminchartView(AdminChartVO acvo) {
		AdminChartVO detail = null;
		detail = chartDAO.adminchartView(acvo);
		return detail;
	}
	public List<OnlineVO> adminonlineList(OnlineVO ovo) {
		List<OnlineVO> myList = null;
		myList = chartDAO.adminonlineList(ovo);
		return myList;
	}
	
	public List<EmailVO> adminemailList(EmailVO evo) {
		List<EmailVO> myList = null;
		myList = chartDAO.adminemailList(evo);
		return myList;
	}
	public List<InterviewApplyVO> admininterList(InterviewApplyVO ivo) {
		List<InterviewApplyVO> myList = null;
		myList = chartDAO.admininterList(ivo);
		return myList;
	}
	public List<ComeOnCompanyVO> admincomeonList(ComeOnCompanyVO cvo) {
		List<ComeOnCompanyVO> myList = null;
		myList = chartDAO.admincomeonList(cvo);
		return myList;
	}
}
