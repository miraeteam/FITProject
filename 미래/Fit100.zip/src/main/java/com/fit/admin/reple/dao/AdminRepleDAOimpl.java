package com.fit.admin.reple.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import com.fit.admin.reple.vo.RepleVO;

public class AdminRepleDAOimpl implements AdminRepleDAO {
	
	@Autowired
	private SqlSession session;


	// 글입력 구현
	@Override
	public  int insertReple(RepleVO revo) {
		return session.insert("insertReple", revo);
	}

	// 글상세 구현
		@Override
		public RepleVO repleDetail(RepleVO revo) {
			return (RepleVO) session.selectOne("repleDetail", revo);
			
		}
}
