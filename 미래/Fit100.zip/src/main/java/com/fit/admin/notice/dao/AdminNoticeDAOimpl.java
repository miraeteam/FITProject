package com.fit.admin.notice.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fit.client.notice.vo.NoticeVO;

@Repository
@Transactional
public class AdminNoticeDAOimpl implements AdminNoticeDAO {
	@Autowired
	private SqlSession session;

	@Override
	public List<NoticeVO> noticeList() {
		return session.selectList("noticeList");
	}

	// 글상세 구현
		@Override
		public NoticeVO adminnoticeDetail(NoticeVO nvo) {
			return (NoticeVO) session.selectOne("adminnoticeDetail", nvo);
		}
		@Override
		public  int insertNotice(NoticeVO nvo) {
			return session.insert("insertNotice", nvo);
		}

}
