package com.fit.admin.qna.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fit.client.member.vo.MemberVO;
import com.fit.client.qna.vo.QnaVO;

@Repository
@Transactional
public class AdminQnaDAOimpl implements AdminQnaDAO {
	@Autowired
	private SqlSession session;

	@Override
	public List<QnaVO> qnaList() {
		return session.selectList("qnaList");
	}

	// 글입력 구현
	@Override
	public  int insertQna(QnaVO bvo) {
		return session.insert("insertQna", bvo);
	}

	// 글상세 구현
		@Override
		public QnaVO qnaDetail(QnaVO qnvo) {
			return (QnaVO) session.selectOne("qnaDetail", qnvo);
		}


	

}
