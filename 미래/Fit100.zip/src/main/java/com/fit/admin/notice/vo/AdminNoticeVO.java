package com.fit.admin.notice.vo;

import java.util.Date;

public class AdminNoticeVO {
	private int N_num;
	private String N_title;
	private String N_content;
	private String Admin_id;
	private Date N_writedate;
	private int N_read;
	public int getN_num() {
		return N_num;
	}
	public void setN_num(int n_num) {
		N_num = n_num;
	}
	public String getN_title() {
		return N_title;
	}
	public void setN_title(String n_title) {
		N_title = n_title;
	}
	public String getN_content() {
		return N_content;
	}
	public void setN_content(String n_content) {
		N_content = n_content;
	}
	public String getAdmin_id() {
		return Admin_id;
	}
	public void setAdmin_id(String admin_id) {
		Admin_id = admin_id;
	}
	public Date getN_writedate() {
		return N_writedate;
	}
	public void setN_writedate(Date n_writedate) {
		N_writedate = n_writedate;
	}
	public int getN_read() {
		return N_read;
	}
	public void setN_read(int n_read) {
		N_read = n_read;
	}
	@Override
	public String toString() {
		return "NoticeVO [N_num=" + N_num + ", N_title=" + N_title + ", N_content=" + N_content + ", Admin_id="
				+ Admin_id + ", N_writedate=" + N_writedate + ", N_read=" + N_read + "]";
	}
	
	
	
	

}

