package com.fit.admin.main;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.fit.admin.chart.service.ChartService;
import com.fit.common.vo.ComeOnCompanyVO;
import com.fit.common.vo.EmailVO;
import com.fit.common.vo.InterviewApplyVO;
import com.fit.common.vo.OnlineVO;

@Controller
@RequestMapping(value = "/admin")
public class AdminMainController {

	@Autowired
	ChartService chartservice;

	@RequestMapping(value = "/main/adminonlineList.do", method = RequestMethod.GET)
	public ModelAndView adminonlineList(OnlineVO ovo, ModelAndView model) {

		List<OnlineVO> onlineList = chartservice.adminonlineList(ovo);
		
		
		
		System.out.println(onlineList);
		model.addObject("adminonlineList", onlineList);
		model.setViewName("admin/main/onlineApply");
		return model;
	}
	
	@RequestMapping(value = "/main/adminemailList.do", method = RequestMethod.GET)
	public ModelAndView adminemailList(EmailVO evo, ModelAndView model) {

		List<EmailVO> emailList = chartservice.adminemailList(evo);
		
		model.addObject("adminemailList", emailList);
		model.setViewName("admin/main/email");
		return model;
	}
	
	@RequestMapping(value = "/main/admininterList.do", method = RequestMethod.GET)
	public ModelAndView admininterList(InterviewApplyVO ivo, ModelAndView model) {

		List<InterviewApplyVO> admininterList = chartservice.admininterList(ivo);
		
		model.addObject("admininterList", admininterList);
		model.setViewName("admin/main/interview");
		return model;
	}
	
	@RequestMapping(value = "/main/admincomeonList.do", method = RequestMethod.GET)
	public ModelAndView admincomeonList(ComeOnCompanyVO cvo, ModelAndView model) {

		List<ComeOnCompanyVO> admincomeonList = chartservice.admincomeonList(cvo);
		
		model.addObject("admincomeonList", admincomeonList);
		model.setViewName("admin/main/comeon");
		return model;
	}
	
	
}
