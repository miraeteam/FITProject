package com.fit.admin;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.fit.admin.chart.service.ChartService;
import com.fit.admin.chart.vo.AdminChartVO;

@Controller
@RequestMapping(value = "/")
public class AdminController {
	@Autowired
	ChartService chartservice;

	Logger logger = LoggerFactory.getLogger(AdminController.class);

	@RequestMapping(value = "/main", method = RequestMethod.GET)
	public ModelAndView admin(AdminChartVO acvo, ModelAndView model, HttpSession session) {

		AdminChartVO detail = new AdminChartVO();
		detail = chartservice.adminchartView(acvo);

		System.out.println(detail + "이거냐?");
		session.setAttribute("admin", detail);

		model.setViewName("mainpage");
		return model;
	}

}
