package com.fit.admin.chart.vo;

public class ChartVO {
 private int  resume_count;
 private int  hire_count;
 private int  member_count;
 private int  company_count;
public int getResume_count() {
	return resume_count;
}
public void setResume_count(int resume_count) {
	this.resume_count = resume_count;
}
public int getHire_count() {
	return hire_count;
}
public void setHire_count(int hire_count) {
	this.hire_count = hire_count;
}
public int getMember_count() {
	return member_count;
}
public void setMember_count(int member_count) {
	this.member_count = member_count;
}
public int getCompany_count() {
	return company_count;
}
public void setCompany_count(int company_count) {
	this.company_count = company_count;
}
@Override
public String toString() {
	return "ChartVO [resume_count=" + resume_count + ", hire_count=" + hire_count + ", member_count=" + member_count
			+ ", company_count=" + company_count + "]";
}
 
 
}
