package com.fit.admin.reple.controller;

import java.io.IOException;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fit.admin.notice.controller.AdminNoticeController;
import com.fit.admin.qna.service.AdminQnaService;
import com.fit.admin.reple.service.AdminRepleService;
import com.fit.admin.reple.vo.RepleVO;
import com.fit.client.qna.vo.QnaVO;

@Controller
@RequestMapping(value = "/admin")
public class AdminRepleController {
	Logger logger = Logger.getLogger(AdminNoticeController.class);

	@Autowired
	private AdminRepleService adminRepleService;
	@Autowired
	private AdminQnaService adminQnaService;

	// 공지사항 상세보기
	@RequestMapping(value = "/reple/repleDetail.do", method = RequestMethod.GET)
	public String aRepleDetail(@ModelAttribute RepleVO revo, Model model) {
		logger.info("repleDetail 호출 성공");
		RepleVO detail = new RepleVO();
		detail = adminRepleService.repleDetail(revo);
		System.out.println(detail.getQ_num());

		model.addAttribute("detailre", detail);
		model.addAttribute("aq_num", detail.getQ_num());
		return "admin/reple/repleDetail";
	}

	/**************************************************************
	 * 글쓰기 폼 출력하기
	 **************************************************************/
	@RequestMapping(value = "/reple/replewrite.do")
	public String awriteForm() {
		logger.info("writeForm 출력");

		return "admin/reple/replewrite";
	}

	@RequestMapping(value = "/reple/insertReple.do", method = RequestMethod.POST)
	   public String aRepleInsert(@ModelAttribute RepleVO revo, @ModelAttribute QnaVO qnvo, Model model,
	         HttpSession session) throws IllegalStateException, IOException {
	      logger.info("관리자 공지 목록추가");
	      int result = 0;
	      String url = "";

	      QnaVO detail = new QnaVO();

	      detail = adminQnaService.qnaDetail(qnvo);// 이 메소드를 타고 들어가서 실행되는 쿼리문에서 믿에 detail.getQ_num(); 의 값을 가져오지 못한다.

	      RepleVO redetail = new RepleVO();
	      redetail = adminRepleService.repleDetail(revo);

	      result = adminRepleService.insertReple(revo);

	      session.setAttribute("qdetail", detail);

	      System.out.println(detail.getQ_num());

	      if (redetail != null && (!redetail.equals(""))) {
	         detail.setQ_title(detail.getQ_title().toString().replaceAll("\n", "<br>"));
	      }
	      model.addAttribute("qdetail", detail);
	      model.addAttribute("detailre", redetail);

	      if (result == 1) {
	         System.out.println("성공");
	         adminQnaService.qnaSelect(detail.getQ_num());
	         url = "/admin/qna/qnaDetail.do?q_num=" + qnvo.getQ_num();
	      } else {
	         System.out.println("실패");
	         url = "/admin/qna/qnaList.do";
	      }
	      return "redirect:" + url;
	}

}
