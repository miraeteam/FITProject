package com.fit.admin.line.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value="/admin")
public class LineController {

	@RequestMapping(value="/static/line.do")
	public String staticLine() {
		return "admin/static/line";
	}
}
