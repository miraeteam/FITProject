package com.fit.admin.qna.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.fit.admin.qna.service.AdminQnaService;
import com.fit.admin.reple.service.AdminRepleService;
import com.fit.admin.reple.vo.RepleVO;
import com.fit.client.qna.vo.QnaVO;

@Controller
@RequestMapping(value = "/admin")
public class AdminQnaController {
	Logger logger = Logger.getLogger(AdminQnaController.class);

	@Autowired
	private SqlSession session;
	@Autowired
	private AdminQnaService adminQnaService;

	@Autowired
	private AdminRepleService adminRepleService;
	@Autowired
	ModelAndView mav;

	/**************************************************************
	 * 리스트보기
	 **************************************************************/
	@RequestMapping(value = "/qna/qnaList.do", method = RequestMethod.GET)
	public String aqnaList(@ModelAttribute QnaVO rvo, @ModelAttribute RepleVO revo, Model model) {
		logger.info("고객문의 츨력");
		String result12;

		RepleVO detailre = new RepleVO();

		List<QnaVO> qnaList = adminQnaService.qnaList();
		model.addAttribute("qnaList", qnaList);
		model.addAttribute("data", rvo);
		model.addAttribute("q_num", revo.getQ_num());

		System.out.println(revo.getQ_num() + "이거");
		return "admin/qna/qnaList";
	}

	/**************************************************************
	 * 글쓰기 폼 출력하기
	 **************************************************************/
	@RequestMapping(value = "/qna/writeQna.do")
	public String awriteForm() {
		logger.info("writeForm 출력");
		return "admin/qna/writeQna";
	}

	/**************************************************************
	 * 글쓰기 구현하기
	 **************************************************************/
	@RequestMapping(value = "/qna/insertQna.do", method = RequestMethod.POST)
	public String aQnaInsert(@ModelAttribute QnaVO qvo, @ModelAttribute RepleVO revo, Model model)
			throws IllegalStateException, IOException {
		logger.info("목록추가");
		int result = 0;
		String url = "";

		result = adminQnaService.insertQna(qvo);

		if (result == 1) {
			url = "/admin/qna/qnaList.do";
		} else {
			url = "/admin/qna/insertQna.do";
		}
		return "redirect:" + url;

	}

	/* 고객문의 상세보기 */
	@RequestMapping(value = "/qna/qnaDetail.do", method = RequestMethod.GET)
	public ModelAndView aqnaDetail(RepleVO revo, QnaVO qnvo, ModelAndView model, HttpSession session) {
		logger.info("qnaDetail �샇異� �꽦怨�");

		QnaVO detail = new QnaVO();

		detail = adminQnaService.qnaDetail(qnvo);
		model.addObject("qdetailr", detail);

		session.setAttribute("qdetail", detail);

		RepleVO detailre = new RepleVO();
		detailre = adminRepleService.repleDetail(revo);
		model.addObject("detailre", detailre);

		model.setViewName("admin/qna/qnaDetail");
		return model;
	}
}
