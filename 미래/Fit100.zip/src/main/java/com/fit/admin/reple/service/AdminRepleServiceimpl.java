package com.fit.admin.reple.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fit.admin.reple.dao.AdminRepleDAO;
import com.fit.admin.reple.vo.RepleVO;
@Service
@Transactional
public class AdminRepleServiceimpl implements AdminRepleService {
	
	
	
	@Autowired
	private AdminRepleDAO adminRepleDAO;

	
	@Override
	public int insertReple(RepleVO revo) {
		int result1 = 0;
		try {
			result1 = adminRepleDAO.insertReple(revo);
		} catch (Exception e) {
			e.printStackTrace();
			result1 = 0;
		}
		return result1;
	}
	@Override
	public RepleVO repleDetail(RepleVO revo) {
		RepleVO detailre = null;
		detailre = adminRepleDAO.repleDetail(revo);
		return detailre;
	}
	
}
