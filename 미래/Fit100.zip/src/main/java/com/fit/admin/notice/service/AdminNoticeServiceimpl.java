package com.fit.admin.notice.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fit.admin.notice.dao.AdminNoticeDAO;
import com.fit.client.notice.vo.NoticeVO;

@Service
@Transactional
public class AdminNoticeServiceimpl implements AdminNoticeService {
	Logger logger = Logger.getLogger(AdminNoticeServiceimpl.class);
	@Autowired
	private SqlSession session;
	@Autowired
	private AdminNoticeDAO adminNoticeDAO;

	public List<NoticeVO> noticeList() {
		List<NoticeVO> myList = null;
		myList = adminNoticeDAO.noticeList();
		return myList;
	}

	// 글상세 구현
	@Override
	public NoticeVO adminnoticeDetail(NoticeVO nvo) {
		return (NoticeVO) session.selectOne("adminnoticeDetail", nvo);
	}
	@Override
	public int insertNotice(NoticeVO nvo) {
		int result = 0;
		try {
			result = adminNoticeDAO.insertNotice(nvo);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}
	

}
