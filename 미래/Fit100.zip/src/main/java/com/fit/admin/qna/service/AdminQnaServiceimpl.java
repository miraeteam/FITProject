package com.fit.admin.qna.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fit.client.qna.dao.QnaDAO;
import com.fit.client.qna.vo.QnaVO;

@Service
@Transactional
public class AdminQnaServiceimpl implements AdminQnaService {
	Logger logger = Logger.getLogger(AdminQnaServiceimpl.class);
	@Autowired
	private QnaDAO qnaDAO;

	public List<QnaVO> qnaList() {
		List<QnaVO> myList = null;
		myList = qnaDAO.qnaList();
		return myList;
	}
	@Override
	public  int insertQna(QnaVO qvo) {
		int result = 0;
		try {
			result = qnaDAO.insertQna(qvo);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}
	@Override
	public QnaVO qnaDetail(QnaVO qnvo) {
		QnaVO detail = null;
		detail = qnaDAO.qnaDetail(qnvo);
		return detail;
	}
	@Override
	public void qnaSelect(int q_num) {
		qnaDAO.qnaSelect(q_num);
	}
}