package com.fit.admin.reple.service;

import com.fit.admin.reple.vo.RepleVO;

public interface AdminRepleService {
	public int insertReple(RepleVO revo);
	public RepleVO repleDetail(RepleVO revo);
}
