package com.fit.admin.notice.service;

import java.util.List;

import com.fit.client.notice.vo.NoticeVO;

public interface AdminNoticeService {
	public List<NoticeVO> noticeList();
	public NoticeVO adminnoticeDetail(NoticeVO nvo);
	  public int insertNotice(NoticeVO nvo);
	
}
