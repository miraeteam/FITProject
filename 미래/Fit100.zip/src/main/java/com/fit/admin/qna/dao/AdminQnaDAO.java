package com.fit.admin.qna.dao;
import java.util.List;

import com.fit.client.qna.vo.QnaVO;

public interface AdminQnaDAO {
	public List<QnaVO> qnaList();
    public int insertQna(QnaVO bvo);
	public QnaVO qnaDetail(QnaVO qdvo);
	
	 
}
