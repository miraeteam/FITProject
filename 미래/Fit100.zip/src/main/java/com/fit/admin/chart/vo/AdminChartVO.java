package com.fit.admin.chart.vo;

public class AdminChartVO {
	private int qnalist;
	private int noticelist;
	private int comeoncompanylist;
	private int emaillist;
	private int interviewlist;
	private int onlinelist;
	public int getQnalist() {
		return qnalist;
	}
	public void setQnalist(int qnalist) {
		this.qnalist = qnalist;
	}
	public int getNoticelist() {
		return noticelist;
	}
	public void setNoticelist(int noticelist) {
		this.noticelist = noticelist;
	}
	public int getComeoncompanylist() {
		return comeoncompanylist;
	}
	public void setComeoncompanylist(int comeoncompanylist) {
		this.comeoncompanylist = comeoncompanylist;
	}
	public int getEmaillist() {
		return emaillist;
	}
	public void setEmaillist(int emaillist) {
		this.emaillist = emaillist;
	}
	public int getInterviewlist() {
		return interviewlist;
	}
	public void setInterviewlist(int interviewlist) {
		this.interviewlist = interviewlist;
	}
	public int getOnlinelist() {
		return onlinelist;
	}
	public void setOnlinelist(int onlinelist) {
		this.onlinelist = onlinelist;
	}
	@Override
	public String toString() {
		return "AdminChartVO [qnalist=" + qnalist + ", noticelist=" + noticelist + ", comeoncompanylist="
				+ comeoncompanylist + ", emaillist=" + emaillist + ", interviewlist=" + interviewlist + ", onlinelist="
				+ onlinelist + "]";
	}
	
	
}
