package com.fit.excel;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.fit.client.hire.service.HireService;
import com.fit.client.hire.vo.HireVO;
import com.fit.client.resume.service.ResumeService;
import com.fit.client.resume.vo.ResumeVO;

@Controller
@RequestMapping(value = "/start")
public class MainController {

   @Autowired
   private ResumeService resumeService;

   @Autowired
   private HireService hireService;

   @RequestMapping("/resumeExcel")
   public ModelAndView resumeExcel(@ModelAttribute ResumeVO rvo, HttpSession session, HttpServletRequest request) {
      List<ResumeVO> resumeList = resumeService.resumeList(rvo);

      ModelAndView mav = new ModelAndView();
      mav.addObject("resumeList", resumeList);
      mav.setViewName("excelView");

      return mav;

   }

   @RequestMapping("/hireExcel")
   public ModelAndView hireExcel(@ModelAttribute HireVO hvo, HttpSession session, HttpServletRequest request) {
      List<HireVO> hireList = hireService.hireList(hvo);

      ModelAndView mav = new ModelAndView();
      mav.addObject("hireList", hireList);
      mav.setViewName("excelView");

      return mav;

   }
}
