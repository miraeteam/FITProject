package com.fit.client.notice.dao;

import java.util.List;

import com.fit.client.notice.vo.NoticeVO;

public interface NoticeDAO {
	public List<NoticeVO> noticeList();
	public NoticeVO noticeDetail(NoticeVO nvo);
	public int noticeListCnt(NoticeVO nvo);
}
