package com.fit.client;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.fit.admin.chart.service.ChartService;
import com.fit.admin.chart.vo.ChartVO;
import com.fit.client.hire.service.HireService;
import com.fit.client.hire.vo.HireVO;
import com.fit.client.resume.service.ResumeService;
import com.fit.client.resume.vo.ResumeVO;
import com.fit.common.vo.CommonVO;

/**
 * Handles requests for the application home page.
 */
@Controller
@RequestMapping(value = "/", method = RequestMethod.GET)
public class HomeController {

	Logger logger = LoggerFactory.getLogger(HomeController.class);

	@Autowired
	private HireService hireService;
	@Autowired
	private ResumeService resumeService;
	@Autowired
	private ChartService chartService; 
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView home(@ModelAttribute HireVO hvo, ChartVO chvo, ResumeVO rvo, ModelAndView model) {
		ChartVO detail = new ChartVO();
		detail = chartService.chartView(chvo);
		
		List<HireVO> hireList = hireService.hireList(hvo);
		List<ResumeVO> resumeList = resumeService.resumeList(rvo);
		
		
		model.addObject("hireList", hireList);
		model.addObject("totalresume", detail);
		model.addObject("resumeList", resumeList);
		model.setViewName("intro");
		return model;
	}

}
