package com.fit.client.notice.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fit.client.notice.service.NoticeService;
import com.fit.client.notice.vo.NoticeVO;
import com.fit.common.page.Paging;

@Controller
@RequestMapping(value = "/notice")
public class NoticeController {
	Logger logger = Logger.getLogger(NoticeController.class);

	@Autowired
	private NoticeService noticeService;

	/**************************************************************
	 * �۸�� �����ϱ�
	 **************************************************************/
	@RequestMapping(value = "/noticeList.do", method = RequestMethod.GET)
	public String noticeList(@ModelAttribute NoticeVO rvo, Model model) {
		logger.info("boardList ȣ�� ����");
		
		Paging.setPage(rvo);
		
		int total = noticeService.noticeListCnt(rvo);
	
		List<NoticeVO> noticeList = noticeService.noticeList();
		model.addAttribute("noticeList", noticeList);
		model.addAttribute("data", rvo);
		model.addAttribute("total", total);
		return "notice/noticeList";
	}
	/*공지사항 상세보기*/
	@RequestMapping(value = "/noticeDetail.do", method = RequestMethod.GET)
	public String noticeDetail(@ModelAttribute NoticeVO nvo, Model model) {
		logger.info("noticeDetail 호출 성공");
		NoticeVO detail = new NoticeVO();
		detail = noticeService.noticeDetail(nvo);
		if (detail != null && (!detail.equals(""))) {
			detail.setN_title(detail.getN_title().toString().replaceAll("\n", "<br>"));
		}
		model.addAttribute("detail", detail);
		return "notice/noticeDetail";
	}

	
}
