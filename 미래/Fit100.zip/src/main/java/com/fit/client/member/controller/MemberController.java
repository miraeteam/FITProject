package com.fit.client.member.controller;

import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fit.client.hire.service.HireService;
import com.fit.client.hire.vo.HireVO;
import com.fit.client.login.service.LoginService;
import com.fit.client.login.vo.LoginVO;
import com.fit.client.member.service.MailService;
import com.fit.client.member.service.MemberService;
import com.fit.client.member.vo.CompanyVO;
import com.fit.client.member.vo.MemberVO;
import com.fit.client.resume.service.ResumeService;
import com.fit.client.resume.vo.ResumeVO;
import com.fit.common.vo.ComeOnCompanyVO;
import com.fit.common.vo.EmailVO;
import com.fit.common.vo.InterviewApplyVO;
import com.fit.common.vo.OnlineVO;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Controller
@RequestMapping(value = "/member")
public class MemberController {
	Logger logger = Logger.getLogger(MemberController.class);

	@Autowired
	private MemberService memberService;

	@Autowired
	private HireService hireService;

	@Autowired
	private ResumeService resumeService;
	@Autowired
	private LoginService loginService;

	private Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();

	@Autowired
	private MailService mailService;

	/**************************************************************
	 * 회원 가입 폼
	 **************************************************************/
	@RequestMapping(value = "/join.do", method = RequestMethod.GET)
	public String joinForm(Model model) {
		logger.info("join.do get 방식에 의한 메서드 호출 성공");
		return "member/join";
	}

	@RequestMapping(value = "/passwordcheck.do", method = RequestMethod.GET)
	public String passwordCheckForm(Model model) {
		return "member/passwordcheck";
	}

	@RequestMapping(value = "/join_company.do", method = RequestMethod.GET)
	public String joinCompanyForm(Model model) {
		logger.info("join_Company.do get 방식에 의한 메서드 호출 성공");
		return "member/join_company";
	}

	@RequestMapping(value = "/porc.do", method = RequestMethod.GET)
	public String porcForm(Model model) {
		logger.info("proc.do get 방식 호출");
		return "member/porc";
	}

	/*************************************************
	 * 사용자 아이디 중복 체크 메서드
	 *************************************************/
	@ResponseBody
	@RequestMapping(value = "/userIdConfirm.do", method = RequestMethod.POST)
	public String userIdConfirm(@RequestParam("userId") String userId) {
		int result = memberService.userIdConfirm(userId);
		return result + "";
	}

	/**************************************************************
	 * 개인 회원 가입 처리
	 **************************************************************/
	@RequestMapping(value = "/join.do", method = RequestMethod.POST)
	public ModelAndView memberInsert(@ModelAttribute MemberVO mvo) {
		logger.info("join.do post 방식에 의한 메서드 호출 성공");
		ModelAndView mav = new ModelAndView();
		int result = 0;
		result = memberService.memberInsert(mvo);
		switch (result) {
		case 1:
			mav.addObject("errCode", 1); // userId already exist
			mav.setViewName("member/join");
			break;
		case 3:
			mav.addObject("errCode", 3);
			mav.setViewName("member/join_success");
			// success to add new member; move to login page
			break;
		default:
			mav.addObject("errCode", 2); // failed to add new member
			mav.setViewName("member/join");
			break;
		}
		return mav;
	}

	/**************************************************************
	 * 기업 회원 가입 처리
	 **************************************************************/
	@RequestMapping(value = "/join_company.do", method = RequestMethod.POST)
	public ModelAndView companyInsert(@ModelAttribute CompanyVO cvo) {
		logger.info("join_company.do post 방식에 의한 메서드 호출 성공");
		ModelAndView mav = new ModelAndView();
		int result = 0;
		result = memberService.companyInsert(cvo);
		switch (result) {
		case 1:
			mav.addObject("errCode", 1); // userId already exist
			mav.setViewName("member/join_comapny");
			break;
		case 3:
			mav.addObject("errCode", 3);
			mav.setViewName("member/join_success");
			// success to add new member; move to login page
			break;
		default:
			mav.addObject("errCode", 2); // failed to add new member
			mav.setViewName("member/join_company");
			break;
		}
		return mav;
	}

	@RequestMapping("/delete.do")
	public ModelAndView memberDelete(HttpSession session) {
		logger.info("delete.do get방식에 의한 메서드 호출 성공");
		ModelAndView mav = new ModelAndView();
		LoginVO login = (LoginVO) session.getAttribute("login");
		if (login == null) {
			mav.setViewName("member/login");
			return mav;
		}
		int errCode = memberService.memberDelete(login.getUserId());
		switch (errCode) {
		case 2:
			mav.setViewName("redirect:/member/logout.do");
			break;
		case 3:
			mav.addObject("errCode", 3);
			mav.setViewName("member/login");
			break;
		}
		return mav;
	}

	@RequestMapping(value = "/memberMypage.do", method = RequestMethod.GET)
	public ModelAndView memberMypage(@ModelAttribute ResumeVO rvo, HttpSession session) {
		logger.info("멤버마이페이지");
		ModelAndView mav = new ModelAndView();

		MemberVO mvo = (MemberVO) session.getAttribute("mvo");
		rvo.setM_num(mvo.getM_num());

		int resumeCount = resumeService.resumeCount(rvo.getM_num());
		int onlineCount = memberService.onlineCount(rvo.getM_num());
		int emailCount = memberService.emailCount(rvo.getM_num());
		int comeOnCompanyCount = memberService.comeOnCompanyCount(rvo.getM_num());
		int interviewApplyCount = memberService.interviewApplyCount(rvo.getM_num());
		
		System.out.println(onlineCount);
		
		mav.addObject("onlineCount", onlineCount);
		mav.addObject("emailCount", emailCount);
		mav.addObject("comeOnCompanyCount", comeOnCompanyCount);
		mav.addObject("interviewApplyCount", interviewApplyCount);
		mav.addObject("resumeCount", resumeCount);
		mav.setViewName("member/memberMypage");

		return mav;

	}
	// 기업 마이페이지 폼 보기

	@RequestMapping(value = "/companyMypage.do", method = RequestMethod.GET)
	public ModelAndView memberMypage(@ModelAttribute HireVO hvo, HttpSession session) {
		logger.info("기업마이페이지");
		ModelAndView mav = new ModelAndView();

		CompanyVO cvo = (CompanyVO) session.getAttribute("comvo");

		hvo.setC_num(cvo.getC_num());

		int hireLiveListCount = hireService.hireLiveListCount(hvo.getC_num());
		int hireDeadListCount = hireService.hireDeadListCount(hvo.getC_num());
		int online_companyCount = memberService.online_companyCount(hvo.getC_num());
		int comeOnCount = memberService.comeOnCount(hvo.getC_num());
		int interviewApply_companyCount = memberService.interviewApply_companyCount(hvo.getC_num());

		mav.addObject("hireLiveListCount", hireLiveListCount);
		mav.addObject("hireDeadListCount", hireDeadListCount);
		mav.addObject("online_companyCount", online_companyCount);
		mav.addObject("comeOnCount", comeOnCount);
		mav.addObject("interviewApply_companyCount", interviewApply_companyCount);
		mav.setViewName("member/companyMypage");

		return mav;

	}

	@RequestMapping(value = "/comeOn.do", method = RequestMethod.GET)
	public ModelAndView comeOn(@ModelAttribute HireVO hvo, HttpSession session) {
		logger.info("컴온 페이지");
		ModelAndView mav = new ModelAndView();

		CompanyVO cvo = (CompanyVO) session.getAttribute("comvo");

		List<ComeOnCompanyVO> comeOnCompanyList = memberService.comeOnList(cvo.getC_num());

		mav.addObject("comvo", cvo);
		mav.addObject("comeOn", comeOnCompanyList);
		mav.setViewName("member/comeOn");

		return mav;

	}

	@RequestMapping(value = "/online_company.do", method = RequestMethod.GET)
	public ModelAndView online_company(@ModelAttribute HireVO hvo, HttpSession session) {
		logger.info("온라인 페이지");
		ModelAndView mav = new ModelAndView();

		CompanyVO cvo = (CompanyVO) session.getAttribute("comvo");

		List<OnlineVO> ovo = memberService.onlineList_company(cvo.getC_num());

		mav.addObject("ovo", ovo);
		mav.addObject("comvo", cvo);
		mav.setViewName("member/online");

		return mav;

	}

	@RequestMapping(value = "/interviewApply_company.do", method = RequestMethod.GET)
	public ModelAndView interviewApply_company(@ModelAttribute HireVO hvo, HttpSession session) {
		logger.info("인터뷰 어플라이");
		ModelAndView mav = new ModelAndView();

		CompanyVO cvo = (CompanyVO) session.getAttribute("comvo");

		List<InterviewApplyVO> ivo = memberService.interviewApply_company(cvo.getC_num());

		mav.addObject("ivo", ivo);
		mav.addObject("comvo", cvo);
		mav.setViewName("member/interviewApply_company");

		return mav;
	}

	/**************************************************************
	 * 기업 회원 수정 처리
	 **************************************************************/
	@RequestMapping(value = "/modify_company.do", method = RequestMethod.GET)
	public ModelAndView modify_company(@ModelAttribute CompanyVO cvo, HttpSession session, HttpServletRequest requset) {
		logger.info("기업회원 수정");

		ModelAndView mav = new ModelAndView();
		LoginVO login = (LoginVO) session.getAttribute("login");

		CompanyVO vo = new CompanyVO();
		vo = memberService.companySelect(login.getUserId());

		System.out.println(cvo);

		mav.addObject("company", vo);
		mav.setViewName("member/modify_company");
		return mav;
	}

	@RequestMapping(value = "/modify_company.do", method = RequestMethod.POST)
	public ModelAndView companyModifyProcess(@ModelAttribute CompanyVO cvo, HttpSession session,
			HttpServletRequest request) {
		logger.info("modify.do post 방식에 의한 메서드 호출 성공");

		ModelAndView mav = new ModelAndView();
		LoginVO login = (LoginVO) session.getAttribute("login");
		cvo.setUserId(login.getUserId());

		CompanyVO vo = new CompanyVO();
		vo = memberService.companySelect(cvo.getUserId());

		if (memberService.companyUpdate(cvo)) {
			mav.setViewName("redirect:/member/logout.do");
			return mav;
		} else {
			mav.addObject("company", vo);
			mav.setViewName("member/modify_company");
			return mav;
		}
	}

	@RequestMapping(value = "/modify.do", method = RequestMethod.GET)
	public ModelAndView modify(@ModelAttribute MemberVO mvo, HttpSession session, HttpServletRequest request) {
		logger.info("개인회원 수정");

		ModelAndView mav = new ModelAndView();
		LoginVO login = (LoginVO) session.getAttribute("login");

		MemberVO vo = new MemberVO();
		vo = memberService.memberSelect(login.getUserId());

		String m_status = vo.getM_status();
		request.setAttribute("m_status", m_status);
		String m_gender = vo.getM_gender();
		request.setAttribute("m_gender", m_gender);

		mav.addObject("member", vo);
		mav.setViewName("member/modify");
		return mav;
	}

	@RequestMapping(value = "/modify.do", method = RequestMethod.POST)
	public ModelAndView memberModifyProcess(@ModelAttribute MemberVO mvo, HttpSession session,
			HttpServletRequest request) {
		logger.info("modify.do post 방식에 의한 메서드 호출 성공");

		ModelAndView mav = new ModelAndView();
		LoginVO login = (LoginVO) session.getAttribute("login");
		mvo.setUserId(login.getUserId());

		MemberVO vo = new MemberVO();
		vo = memberService.memberSelect(mvo.getUserId());

		System.out.println(mvo);
		if (memberService.memberUpdate(mvo)) {
			mav.setViewName("redirect:/member/logout.do");
			return mav;
		} else {
			mav.addObject("member", vo);
			mav.setViewName("member/modify");
			return mav;
		}
	}

	@RequestMapping(value = "/comeOnCompany.do", method = RequestMethod.GET)
	public ModelAndView comeOnCompany(@ModelAttribute ResumeVO rvo, HttpSession session) {
		logger.info("컴온 페이지");
		ModelAndView mav = new ModelAndView();

		MemberVO mvo = (MemberVO) session.getAttribute("mvo");

		List<ComeOnCompanyVO> comeOnCompanyList = memberService.comeOnCompanyList(mvo.getM_num());

		mav.addObject("mvo", mvo);
		mav.addObject("comeOnCompanyList", comeOnCompanyList);
		mav.setViewName("member/comeOnCompany");

		return mav;

	}

	@RequestMapping(value = "/interviewApply.do", method = RequestMethod.GET)
	public ModelAndView interviewApply(@ModelAttribute ResumeVO rvo, HttpSession session) {
		logger.info("인터뷰 페이지");
		ModelAndView mav = new ModelAndView();

		MemberVO mvo = (MemberVO) session.getAttribute("mvo");

		List<InterviewApplyVO> interviewList = memberService.interviewList(mvo.getM_num());

		mav.addObject("mvo", mvo);
		mav.addObject("interviewList", interviewList);
		mav.setViewName("member/interviewApply");

		return mav;

	}

	@RequestMapping(value = "/onlineApply.do", method = RequestMethod.GET)
	public ModelAndView onlineApply(@ModelAttribute ResumeVO rvo, HttpSession session) {
		logger.info("온라인지원 페이지");
		ModelAndView mav = new ModelAndView();

		MemberVO mvo = (MemberVO) session.getAttribute("mvo");

		List<OnlineVO> onlineList = memberService.onlineList(mvo.getM_num());

		mav.addObject("mvo", mvo);
		mav.addObject("onlineList", onlineList);
		mav.setViewName("member/onlineApply");

		return mav;

	}

	@RequestMapping(value = "/email.do", method = RequestMethod.GET)
	public ModelAndView emailApply(@ModelAttribute ResumeVO rvo, HttpSession session) {
		logger.info("온라인지원 페이지");
		ModelAndView mav = new ModelAndView();

		MemberVO mvo = (MemberVO) session.getAttribute("mvo");

		List<EmailVO> emailList = memberService.emailList(mvo.getM_num());

		mav.addObject("mvo", mvo);
		mav.addObject("emailList", emailList);
		mav.setViewName("member/email");

		return mav;

	}

	// 비밀번호 확인
	@RequestMapping(value = "/pwcheck.do", method = RequestMethod.POST)
	public ModelAndView memberPwCheck(@ModelAttribute("LoginVO") LoginVO lvo, HttpSession session,
			HttpServletRequest request) {
		logger.info("checkPw.do post 방식에 의한 메서드 호출 성공");
		ModelAndView mav = new ModelAndView();
		System.out.println(lvo.getUserId());
		System.out.println(lvo.getUserPw());
		LoginVO memberCheckPw = loginService.loginSelect(lvo.getUserId(), lvo.getUserPw());

		if (memberCheckPw != null) {// 실패
			mav.setViewName("redirect:/member/modify.do");
			return mav;

		} else {

			mav.setViewName("member/passwordcheck");
		}
		return mav;
	}

	@ResponseBody
	@RequestMapping(value = "/checkMail.do", produces = "text/plain; charset=UTF-8")
	public String memberCheckMail(@RequestParam String email) {
		MemberVO mvo = new MemberVO();
		mvo.setEmail(email);
		return gson.toJson(mvo);
	}
	@ResponseBody
	@RequestMapping(value = "/companyCheckMail.do", produces = "text/plain; charset=UTF-8")
	public String companyCheckMail(@RequestParam String email) {
		CompanyVO cvo = new CompanyVO();
		cvo.setEmail(email);
		return gson.toJson(cvo);
	}

	@ResponseBody
	@RequestMapping(value = "/sendMail.do", method = RequestMethod.POST, produces = "application/json")
	private boolean sendMail(HttpSession session, @RequestParam String email) {
		logger.info("메일보내기");
		int randomCode = new Random().nextInt(10000) + 1000;
		// 문자열 숫자변환.
		String joinCode = String.valueOf(randomCode);
		session.setAttribute("joinCode", joinCode);
		System.out.println(session.getAttribute("joinCode"));
		String subject = "회원가입 승인 번호 입니다.";
		StringBuilder sb = new StringBuilder();
		sb.append("회원가입 승인번호는 ").append(joinCode).append(" 입니다.");
		return mailService.send(subject, sb.toString(), "styleo4401@gmail.com", email);
	}

	@ResponseBody
	@RequestMapping(value = "/emailKeyCheck.do", method = RequestMethod.POST, produces = "text/plain; charset=UTF-8")
	private String emailKeyCheck(HttpSession session, @ModelAttribute MemberVO memberVO) {
		logger.info("메일체크");
		System.out.println("vo 값 : " + memberVO.getKey());
		System.out.println("session 값 : " + session.getAttribute("joinCode"));
		String clientkey = memberVO.getKey();
		String key = (String) session.getAttribute("joinCode");
		String value = "";
		if (clientkey.equals(key)) {
			value = "성공";
			System.out.println("인증성공");
		} else {
			value = "실패";
			System.out.println("인증실패");
		}
		System.out.println(value);
		return value;
	}
	
	@ResponseBody
	@RequestMapping(value = "/companyEmailKeyCheck.do", method = RequestMethod.POST, produces = "text/plain; charset=UTF-8")
	private String emailKeyCheck(HttpSession session, @ModelAttribute CompanyVO cvo) {
		logger.info("메일체크");
		System.out.println("vo 값 : " + cvo.getKey());
		System.out.println("session 값 : " + session.getAttribute("joinCode"));
		String clientkey = cvo.getKey();
		String key = (String) session.getAttribute("joinCode");
		String value = "";
		if (clientkey.equals(key)) {
			value = "성공";
			System.out.println("인증성공");
		} else {
			value = "실패";
			System.out.println("인증실패");
		}
		System.out.println(value);
		return value;
	}
}
