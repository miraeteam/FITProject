package com.fit.client.qna.dao;
import java.util.List;

import com.fit.client.notice.vo.NoticeVO;
import com.fit.client.qna.vo.QnaVO;

public interface QnaDAO {
	public List<QnaVO> qnaList();
    public int insertQna(QnaVO bvo);
	public QnaVO qnaDetail(QnaVO qdvo);
	public void qnaSelect(int q_num);
	public int qnaListCnt(QnaVO nvo);
}
