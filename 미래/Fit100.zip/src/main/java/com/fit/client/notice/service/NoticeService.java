package com.fit.client.notice.service;

import java.util.List;

import com.fit.client.notice.vo.NoticeVO;

public interface NoticeService {
	public List<NoticeVO> noticeList();
	public NoticeVO noticeDetail(NoticeVO nvo);
	public int noticeListCnt(NoticeVO nvo);

}
