package com.fit.client.member.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fit.client.member.vo.CompanyVO;
import com.fit.client.member.vo.MemberSecurity;
import com.fit.client.member.vo.MemberVO;
import com.fit.common.vo.ComeOnCompanyVO;
import com.fit.common.vo.EmailVO;
import com.fit.common.vo.InterviewApplyVO;
import com.fit.common.vo.OnlineVO;

@Repository
public class MemberDaoImpl implements MemberDao {

	@Autowired
	private SqlSession session;

	@Override
	public int securityInsert(MemberSecurity userId) {
		return session.insert("securityInsert", userId);
	}

	@Override
	public MemberSecurity securitySelect(String userId) {
		return (MemberSecurity) session.selectOne("securitySelect", userId);
	}

	@Override
	public int securityDelete(String userId) {
		return session.delete("securityDelete", userId);
	}

	@Override
	public MemberVO memberSelect(String userId) {
		return (MemberVO) session.selectOne("memberSelect", userId);
	}

	@Override
	public int memberInsert(MemberVO mvo) {
		return session.insert("memberInsert", mvo);
	}

	@Override
	public int memberUpdate(MemberVO mvo) {
		return session.update("memberUpdate", mvo);
	}

	@Override
	public int memberDelete(String userId) {
		return session.delete("memberDelete", userId);
	}

	@Override
	public int companyInsert(CompanyVO cvo) {
		return session.insert("companyInsert", cvo);
	}

	@Override
	public CompanyVO companySelect(String userId) {
		return (CompanyVO) session.selectOne("companySelect", userId);
	}

	@Override
	public int companyUpdate(CompanyVO cvo) {
		return session.update("companyUpdate", cvo);
	}

	@Override
	public int emailInsert(EmailVO evo) {
		return session.insert("emailInsert", evo);
	}

	@Override
	public int onlineInsert(OnlineVO ovo) {
		return session.insert("onlineInsert", ovo);
	}

	@Override
	public int comeOnInsert(ComeOnCompanyVO covo) {
		return session.insert("comeOnInsert", covo);
	}

	@Override
	public int interviewApply(InterviewApplyVO ivo) {
		return session.insert("interviewApply", ivo);
	}

	@Override
	public List<ComeOnCompanyVO> comeOnCompanyList(int m_num) {
		return session.selectList("comeOnCompanyList");
	}

	public List<InterviewApplyVO> interviewList(int m_num) {
		return session.selectList("interviewList");
	}

	public List<OnlineVO> onlineList(int m_num) {
		return session.selectList("onlineList");
	}

	public List<EmailVO> emailList(int m_num) {
		return session.selectList("emailList");
	}

	// 온라인 수
	public int onlineCount(int m_num) {
		return session.selectOne("onlineCount", m_num);
	}

	// 이메일 수
	public int emailCount(int m_num) {
		return session.selectOne("emailCount", m_num);
	}

	// 입사지원요청 수
	public int comeOnCompanyCount(int m_num) {
		return session.selectOne("comeOnCompanyCount", m_num);
	}

	// 면접제의 수
	public int interviewApplyCount(int m_num) {
		return session.selectOne("interviewApplyCount", m_num);
	}

	public int pwdConfirm(MemberVO mvo) {
		return (Integer) session.selectOne("pwdConfirm", mvo);
	}
	@Override
	public List<ComeOnCompanyVO> comeOnList(int c_num) {
		return session.selectList("comeOnList", c_num);
	}

	@Override
	public List<OnlineVO> onlineList_company(int c_num) {
		return session.selectList("onlineList", c_num);
	}

	@Override
	public List<InterviewApplyVO> interviewApply_company(int c_num) {
		return session.selectList("interviewApply_company", c_num);
	}

	@Override
	public int online_companyCount(int c_num) {
		return session.selectOne("online_companyCount", c_num);
	}

	@Override
	public int comeOnCount(int c_num) {
		return session.selectOne("comeOnCount", c_num);
	}

	@Override
	public int interviewApply_companyCount(int c_num) {
		return session.selectOne("interviewApply_companyCount", c_num);
	}
}
