package com.fit.client.resume.dao;

import java.util.List;

import com.fit.client.resume.vo.ResumeVO;

public interface ResumeDAO {
	public List<ResumeVO> resumeList(ResumeVO rvo);

	public ResumeVO resumeDetail(ResumeVO rvo);

	public int resumeInsert(ResumeVO rvo);

	public List<ResumeVO> myResumeList(int m_num);

	public int resumeCount(int m_num);

	public int resumeListCnt(ResumeVO rvo);
}
