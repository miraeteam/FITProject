package com.fit.client.hire.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fit.client.hire.dao.HireDAO;
import com.fit.client.hire.vo.HireVO;
import com.fit.client.resume.vo.ResumeVO;

@Service
@Transactional
public class HireServiceImpl implements HireService {
	Logger logger = Logger.getLogger(HireServiceImpl.class);

	@Autowired
	private HireDAO hireDAO;

	public List<HireVO> hireList(HireVO hvo) {
		List<HireVO> myList = null;
		myList = hireDAO.hireList(hvo);
		return myList;
	}

	@Override
	public List<HireVO> hireLiveList() {
		List<HireVO> myLiveList = null;
		myLiveList = hireDAO.hireLiveList();
		return myLiveList;
	}

	@Override
	public List<HireVO> hireDeadList() {
		List<HireVO> myDeadList = null;
		myDeadList = hireDAO.hireDeadList();
		return myDeadList;
	}

	public HireVO hireDetail(HireVO hvo) {
		HireVO detail = null;
		detail = hireDAO.hireDetail(hvo);
		return detail;
	}

	public int hireInsert(HireVO hvo) {
		int result = 0;
		try {
			result = hireDAO.hireInsert(hvo);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	public List<HireVO> myHire(int c_num) {
		List<HireVO> myHireList = null;
		myHireList = hireDAO.myHire(c_num);
		return myHireList;
	}

	public int hireListCnt(HireVO hvo) {
		return hireDAO.hireListCnt(hvo);
	}

	@Override
	public int hireLiveListCount(int c_num) {
		int result = 0;
		try {
			result = hireDAO.hireLiveListCount(c_num);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	@Override
	public int hireDeadListCount(int c_num) {
		int result = 0;
		try {
			result = hireDAO.hireDeadListCount(c_num);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}
}
