package com.fit.client.qna.vo;

import java.util.Date;

import com.fit.client.login.vo.LoginVO;

public class QnaVO extends LoginVO{
	private int Q_num;
	private String Q_title;
	private String Q_content;
	private String whichmember;
	private Date Q_date;
	private String Q_email;
	private String Q_secret;
	private String Q_link;
	private String Q_answer;
	
	private String page;	//페이지 번호
	private String pageSize;	//페이지에 보여주는 줄수
	private String start_row;	//시작 레코드 번호
	private String end_row;		//종료 레코드 번호
	//조건 검색 시 사용할 필드
	private String search = "";
	private String keyword= "";
	//제목 클릭시 정렬을 위한 필드
	private String order_by;
	private String order_sc;
	
	

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getPageSize() {
		return pageSize;
	}

	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}

	public String getStart_row() {
		return start_row;
	}

	public void setStart_row(String start_row) {
		this.start_row = start_row;
	}

	public String getEnd_row() {
		return end_row;
	}

	public void setEnd_row(String end_row) {
		this.end_row = end_row;
	}

	public String getSearch() {
		return search;
	}

	public void setSearch(String search) {
		this.search = search;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getOrder_by() {
		return order_by;
	}

	public void setOrder_by(String order_by) {
		this.order_by = order_by;
	}

	public String getOrder_sc() {
		return order_sc;
	}

	public void setOrder_sc(String order_sc) {
		this.order_sc = order_sc;
	}

	public int getQ_num() {
		return Q_num;
	}

	public void setQ_num(int q_num) {
		Q_num = q_num;
	}

	public String getQ_title() {
		return Q_title;
	}

	public void setQ_title(String q_title) {
		Q_title = q_title;
	}

	public String getQ_content() {
		return Q_content;
	}

	public void setQ_content(String q_content) {
		Q_content = q_content;
	}

	public String getWhichmember() {
		return whichmember;
	}

	public void setWhichmember(String whichmember) {
		this.whichmember = whichmember;
	}

	public Date getQ_date() {
		return Q_date;
	}

	public void setQ_date(Date q_date) {
		Q_date = q_date;
	}

	public String getQ_email() {
		return Q_email;
	}

	public void setQ_email(String q_email) {
		Q_email = q_email;
	}

	public String getQ_secret() {
		return Q_secret;
	}

	public void setQ_secret(String q_secret) {
		Q_secret = q_secret;
	}

	public String getQ_link() {
		return Q_link;
	}

	public void setQ_link(String q_link) {
		Q_link = q_link;
	}

	public String getQ_answer() {
		return Q_answer;
	}

	public void setQ_answer(String q_answer) {
		Q_answer = q_answer;
	}

	@Override
	public String toString() {
		return "QnaVO [Q_num=" + Q_num + ", Q_title=" + Q_title + ", Q_content=" + Q_content + ", whichmember="
				+ whichmember + ", Q_date=" + Q_date + ", Q_email=" + Q_email + ", Q_secret=" + Q_secret + ", Q_link="
				+ Q_link + ", Q_answer=" + Q_answer + "]";
	}

	

	
}
