package com.fit.client.notice.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fit.client.notice.vo.NoticeVO;

@Repository
@Transactional
public class NoticeDAOimpl implements NoticeDAO {
	@Autowired
	private SqlSession session;

	@Override
	public List<NoticeVO> noticeList() {
		return session.selectList("noticeList");
	}

	// 글상세 구현
		@Override
		public NoticeVO noticeDetail(NoticeVO nvo) {
			return (NoticeVO) session.selectOne("noticeDetail", nvo);
		}
		public int noticeListCnt(NoticeVO nvo) {
			return session.selectOne("noticeListCnt");
		}

}
