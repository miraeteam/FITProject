package com.fit.client.resume.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fit.client.resume.dao.ResumeDAO;
import com.fit.client.resume.vo.ResumeVO;

@Service
@Transactional
public class ResumeServiceImpl implements ResumeService {
	Logger logger = Logger.getLogger(ResumeServiceImpl.class);

	@Autowired
	private ResumeDAO resumeDAO;

	// 이력서 리스트
	@Override
	public List<ResumeVO> resumeList(ResumeVO rvo) {
		List<ResumeVO> myList = null;
		if (rvo.getOrder_by() == null)
			rvo.setOrder_by("r_num");
		if (rvo.getOrder_sc() == null)
			rvo.setOrder_sc("DESC");
		myList = resumeDAO.resumeList(rvo);
		return myList;
	}

	// 내 이력서 리스트
	@Override
	public List<ResumeVO> myResumeList(int m_num) {
		List<ResumeVO> myList = null;
		myList = resumeDAO.myResumeList(m_num);
		return myList;
	}

	// 글입력 구현
	@Override
	public int resumeInsert(ResumeVO rvo) {
		int result = 0;
		try {
			result = resumeDAO.resumeInsert(rvo);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	// 이력서 상세보기
	@Override
	public ResumeVO resumeDetail(ResumeVO rvo) {
		ResumeVO detail = null;
		detail = resumeDAO.resumeDetail(rvo);
		return detail;
	}

	// 이력서 수
	public int resumeCount(int m_num) {
		int result = 0;
		try {
			result = resumeDAO.resumeCount(m_num);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	public int resumeListCnt(ResumeVO rvo) {
		return resumeDAO.resumeListCnt(rvo);
	}

}
