package com.fit.client.member.service;

public interface MailService {
	boolean send(String subject, String text, String from,String to);

}
