package com.fit.client.hire.vo;

import java.sql.Timestamp;

import com.fit.client.member.vo.CompanyVO;

public class HireVO extends CompanyVO {
	private int H_num;
	private String H_choice;
	private String H_major;
	private String H_salary;
	private String H_location;
	private String H_workTime;
	private String H_career;
	private String H_gender;
	private String H_workType;
	private String H_insurance;
	private String H_workDay;
	private String H_deadLine;
	private String H_title;
	private String h_hiredetail;
	private String H_accept;
	private String h_resumeForm;
	private String H_count;
	private Timestamp h_insertdate;

	private String page; // 페이지 번호
	private String pageSize; // 페이지에 보여주는 줄수
	private String start_row; // 시작 레코드 번호
	private String end_row; // 종료 레코드 번호
	// 조건 검색 시 사용할 필드
	private String search = "";
	private String keyword = "";
	// 제목 클릭시 정렬을 위한 필드
	private String order_by;
	private String order_sc;

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getPageSize() {
		return pageSize;
	}

	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}

	public String getStart_row() {
		return start_row;
	}

	public void setStart_row(String start_row) {
		this.start_row = start_row;
	}

	public String getEnd_row() {
		return end_row;
	}

	public void setEnd_row(String end_row) {
		this.end_row = end_row;
	}

	public String getSearch() {
		return search;
	}

	public void setSearch(String search) {
		this.search = search;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getOrder_by() {
		return order_by;
	}

	public void setOrder_by(String order_by) {
		this.order_by = order_by;
	}

	public String getOrder_sc() {
		return order_sc;
	}

	public void setOrder_sc(String order_sc) {
		this.order_sc = order_sc;
	}

	public String getH_count() {
		return H_count;
	}

	public void setH_count(String h_count) {
		H_count = h_count;
	}

	public Timestamp getH_insertdate() {
		return h_insertdate;
	}

	public void setH_insertdate(Timestamp h_insertdate) {
		this.h_insertdate = h_insertdate;
	}

	public int getH_num() {
		return H_num;
	}

	public String getH_workDay() {
		return H_workDay;
	}

	public void setH_workDay(String h_workDay) {
		H_workDay = h_workDay;
	}

	public String getH_deadLine() {
		return H_deadLine;
	}

	public void setH_deadLine(String h_deadLine) {
		H_deadLine = h_deadLine;
	}

	public void setH_num(int h_num) {
		H_num = h_num;
	}

	public String getH_choice() {
		return H_choice;
	}

	public void setH_choice(String h_choice) {
		H_choice = h_choice;
	}

	public String getH_major() {
		return H_major;
	}

	public void setH_major(String h_major) {
		H_major = h_major;
	}

	public String getH_salary() {
		return H_salary;
	}

	public void setH_salary(String h_salary) {
		H_salary = h_salary;
	}

	public String getH_location() {
		return H_location;
	}

	public void setH_location(String h_location) {
		H_location = h_location;
	}

	public String getH_workTime() {
		return H_workTime;
	}

	public void setH_workTime(String h_workTime) {
		H_workTime = h_workTime;
	}

	public String getH_career() {
		return H_career;
	}

	public void setH_career(String h_career) {
		H_career = h_career;
	}

	public String getH_gender() {
		return H_gender;
	}

	public void setH_gender(String h_gender) {
		H_gender = h_gender;
	}

	public String getH_workType() {
		return H_workType;
	}

	public void setH_workType(String h_workType) {
		H_workType = h_workType;
	}

	public String getH_insurance() {
		return H_insurance;
	}

	public void setH_insurance(String h_insurance) {
		H_insurance = h_insurance;
	}

	public String getH_title() {
		return H_title;
	}

	public void setH_title(String h_title) {
		H_title = h_title;
	}

	public String getH_hiredetail() {
		return h_hiredetail;
	}

	public void setH_hiredetail(String h_hiredetail) {
		this.h_hiredetail = h_hiredetail;
	}

	public String getH_accept() {
		return H_accept;
	}

	public void setH_accept(String h_accept) {
		H_accept = h_accept;
	}

	public String getH_resumeForm() {
		return h_resumeForm;
	}

	public void setH_resumeForm(String h_resumeForm) {
		this.h_resumeForm = h_resumeForm;
	}

}
