package com.fit.client.member.vo;

import java.sql.Timestamp;

import com.fit.client.login.vo.LoginVO;

/**
 * @author msi
 *
 */
public class CompanyVO extends LoginVO {
	private String key;
	private int c_num;
	private String c_logo;
	private String c_photo;
	private String c_companyName;
	private String c_name;
	private String address;
	private String c_tel;
	private String c_phone;
	private String c_fax;
	private String email;
	private String c_homepage;
	private String c_companyNumber;
	private Timestamp c_joindate;

	public int getC_num() {
		return c_num;
	}

	public void setC_num(int c_num) {
		this.c_num = c_num;
	}

	public String getC_logo() {
		return c_logo;
	}

	public void setC_logo(String c_logo) {
		this.c_logo = c_logo;
	}

	public String getC_photo() {
		return c_photo;
	}

	public void setC_photo(String c_photo) {
		this.c_photo = c_photo;
	}

	public String getC_companyName() {
		return c_companyName;
	}

	public void setC_companyName(String c_companyName) {
		this.c_companyName = c_companyName;
	}

	public String getC_name() {
		return c_name;
	}

	public void setC_name(String c_name) {
		this.c_name = c_name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getC_tel() {
		return c_tel;
	}

	public void setC_tel(String c_tel) {
		this.c_tel = c_tel;
	}

	public String getC_phone() {
		return c_phone;
	}

	public void setC_phone(String c_phone) {
		this.c_phone = c_phone;
	}

	public String getC_fax() {
		return c_fax;
	}

	public void setC_fax(String c_fax) {
		this.c_fax = c_fax;
	}

	public String getC_homepage() {
		return c_homepage;
	}

	public void setC_homepage(String c_homepage) {
		this.c_homepage = c_homepage;
	}

	public String getC_companyNumber() {
		return c_companyNumber;
	}

	public void setC_companyNumber(String c_companyNumber) {
		this.c_companyNumber = c_companyNumber;
	}

	public Timestamp getC_joindate() {
		return c_joindate;
	}

	public void setC_joindate(Timestamp c_joindate) {
		this.c_joindate = c_joindate;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	@Override
	public String toString() {
		return "CompanyVO [key=" + key + ", c_num=" + c_num + ", c_logo=" + c_logo + ", c_photo=" + c_photo
				+ ", c_companyName=" + c_companyName + ", c_name=" + c_name + ", address=" + address + ", c_tel="
				+ c_tel + ", c_phone=" + c_phone + ", c_fax=" + c_fax + ", email=" + email + ", c_homepage="
				+ c_homepage + ", c_companyNumber=" + c_companyNumber + ", c_joindate=" + c_joindate + "]";
	}

}
