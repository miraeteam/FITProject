package com.fit.client.member.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fit.client.member.dao.MemberDao;
import com.fit.client.member.vo.CompanyVO;
import com.fit.client.member.vo.MemberSecurity;
import com.fit.client.member.vo.MemberVO;
import com.fit.common.util.OpenCrypt;
import com.fit.common.util.Util;
import com.fit.common.vo.ComeOnCompanyVO;
import com.fit.common.vo.EmailVO;
import com.fit.common.vo.InterviewApplyVO;
import com.fit.common.vo.OnlineVO;

@Service
@Transactional
public class MemberServiceImpl implements MemberService {
	Logger logger = Logger.getLogger(MemberServiceImpl.class);

	@Autowired
	private MemberDao memberDao;

	public int pwdConfirm(MemberVO mvo) {
		int result = 0;
		result = memberDao.pwdConfirm(mvo);
		return result;
	}

	@Override
	public int userIdConfirm(String userId) {
		int result;
		if (memberDao.memberSelect(userId) != null) {
			result = 1;
		} else {
			result = 2;
		}
		return result;
	}

	@Override
	public MemberVO memberSelect(String userId) {
		MemberVO vo = memberDao.memberSelect(userId);
		return vo;
	}

	@Override
	public int memberInsert(MemberVO mvo) {
		int sCode = 2;
		if (memberDao.memberSelect(mvo.getUserId()) != null) {
			return 1;
		} else {
			try {
				MemberSecurity sec = new MemberSecurity();
				sec.setUserId(mvo.getUserId());
				sec.setSalt(Util.getRandomString());
				sCode = memberDao.securityInsert(sec);
				if (sCode == 1) {
					mvo.setUserPw(new String(OpenCrypt.getSHA256(mvo.getUserPw(), sec.getSalt())));
					memberDao.memberInsert(mvo);
					return 3;
				} else {
					return 2;
				}
			} catch (RuntimeException e) {
				e.printStackTrace();
				return 2;
			}
		}
	}

	@Override
	public boolean memberUpdate(MemberVO mvo) {
		try {
			if (!mvo.getUserPw().isEmpty()) {
				MemberSecurity sec = memberDao.securitySelect(mvo.getUserId());
				mvo.setUserPw(new String(OpenCrypt.getSHA256(mvo.getUserPw(), sec.getSalt())));
			}
			memberDao.memberUpdate(mvo);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;

	}

	@Override
	public int memberDelete(String userId) {
		int mCode, sCode, isSucessCode = 3;
		try {
			mCode = memberDao.memberDelete(userId);
			if (mCode == 1) {
				sCode = memberDao.securityDelete(userId);
				if (sCode == 1) {
					isSucessCode = 2;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			isSucessCode = 3;
		}
		return isSucessCode;
	}

	@Override
	public int companyInsert(CompanyVO cvo) {
		int sCode = 2;
		if (memberDao.companySelect(cvo.getUserId()) != null) {
			return 1;
		} else {
			try {
				MemberSecurity sec = new MemberSecurity();
				sec.setUserId(cvo.getUserId());
				sec.setSalt(Util.getRandomString());
				sCode = memberDao.securityInsert(sec);
				if (sCode == 1) {
					cvo.setUserPw(new String(OpenCrypt.getSHA256(cvo.getUserPw(), sec.getSalt())));
					memberDao.companyInsert(cvo);
					return 3;
				} else {
					return 2;
				}
			} catch (RuntimeException e) {
				e.printStackTrace();
				return 2;
			}
		}
	}

	@Override
	public CompanyVO companySelect(String userId) {
		CompanyVO vo = memberDao.companySelect(userId);
		return vo;
	}

	@Override
	public boolean companyUpdate(CompanyVO cvo) {
		try {
			if (!cvo.getUserPw().isEmpty()) {
				MemberSecurity sec = memberDao.securitySelect(cvo.getUserId());
				cvo.setUserPw(new String(OpenCrypt.getSHA256(cvo.getUserPw(), sec.getSalt())));
			}
			memberDao.companyUpdate(cvo);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	@Override
	public int emailInsert(EmailVO evo) {
		memberDao.emailInsert(evo);
		return 1;

	}

	@Override
	public int onlineInsert(OnlineVO ovo) {
		memberDao.onlineInsert(ovo);
		return 1;
	}

	@Override
	public int comeOnInsert(ComeOnCompanyVO covo) {
		memberDao.comeOnInsert(covo);
		return 1;
	}

	@Override
	public int interviewApply(InterviewApplyVO ivo) {
		memberDao.interviewApply(ivo);
		return 1;
	}

	public List<ComeOnCompanyVO> comeOnCompanyList(int m_num) {
		List<ComeOnCompanyVO> myList = null;
		myList = memberDao.comeOnCompanyList(m_num);
		return myList;
	}

	public List<InterviewApplyVO> interviewList(int m_num) {
		List<InterviewApplyVO> myList = null;
		myList = memberDao.interviewList(m_num);
		return myList;
	}

	public List<OnlineVO> onlineList(int m_num) {
		List<OnlineVO> myList = null;
		myList = memberDao.onlineList(m_num);
		return myList;
	}

	public List<EmailVO> emailList(int m_num) {
		List<EmailVO> myList = null;
		myList = memberDao.emailList(m_num);
		return myList;
	}

	// 온라인 수
	public int onlineCount(int m_num) {
		int result = 0;
		try {
			result = memberDao.onlineCount(m_num);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	// 이메일 수
	public int emailCount(int m_num) {
		int result = 0;
		try {
			result = memberDao.emailCount(m_num);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	// 입사지원요청 수
	public int comeOnCompanyCount(int m_num) {
		int result = 0;
		try {
			result = memberDao.comeOnCompanyCount(m_num);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	// 면접요청 수
	public int interviewApplyCount(int m_num) {
		int result = 0;
		try {
			result = memberDao.interviewApplyCount(m_num);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}
	@Override
	public List<ComeOnCompanyVO> comeOnList(int c_num) {
		List<ComeOnCompanyVO> myList = null;
		myList = memberDao.comeOnList(c_num);
		return myList;

	}

	@Override
	public List<OnlineVO> onlineList_company(int c_num) {
		List<OnlineVO> myList = null;
		myList = memberDao.onlineList_company(c_num);
		return myList;
	}

	@Override
	public List<InterviewApplyVO> interviewApply_company(int c_num) {
		List<InterviewApplyVO> myList = null;
		myList = memberDao.interviewApply_company(c_num);
		return myList;
	}

	@Override
	public int online_companyCount(int c_num) {
		int result = 0;
		try {
			result = memberDao.online_companyCount(c_num);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}
	@Override
	public int comeOnCount(int c_num) {
		int result = 0;
		try {
			result = memberDao.comeOnCount(c_num);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	@Override
	public int interviewApply_companyCount(int c_num) {
		int result = 0;
		try {
			result = memberDao.interviewApply_companyCount(c_num);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	
}
