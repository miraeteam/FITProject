package com.fit.client.login.dao;

import com.fit.client.login.vo.LoginVO;

public interface LoginDao {
	public LoginVO userIdSelect(String userId);
	public LoginVO companyUserIdSelect(String userId);
	public LoginVO loginSelect(LoginVO lvo);
	public LoginVO companyLoginSelect(LoginVO lvo);
	public int loginHistoryInsert(LoginVO lvo);
	public int companyLoginHistoryInsert(LoginVO lvo);
	public int loginHistoryUpdate(LoginVO lvo);
	public LoginVO loginHistorySelect(String userId); 
}
