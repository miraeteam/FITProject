package com.fit.client.hire.service;

import java.util.List;

import com.fit.client.hire.vo.HireVO;

public interface HireService {
	public List<HireVO> hireList(HireVO hvo);
	
	public HireVO hireDetail(HireVO hvo);
	
	public int hireInsert(HireVO hvo);
	
	public List<HireVO> myHire(int c_num);
	public int hireListCnt(HireVO hvo);
	
	public List<HireVO> hireLiveList();
	
	public List<HireVO> hireDeadList();
	
	public int hireLiveListCount(int c_num);
	
	public int hireDeadListCount(int c_num);
}
