package com.fit.client.resume.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fit.client.resume.vo.ResumeVO;

@Repository
@Transactional
public class ResumeDAOImpl implements ResumeDAO {
	
	@Autowired
	private SqlSession session;


	@Override
	public List<ResumeVO> resumeList(ResumeVO rvo) {
		return session.selectList("resumeList", rvo);
	}

	public List<ResumeVO> myResumeList(int m_num) {
		return session.selectList("myResumeList");
	}

	// 글상세 구현
	@Override
	public ResumeVO resumeDetail(ResumeVO rvo) {
		return (ResumeVO) session.selectOne("resumeDetail", rvo);
	}

	// 글입력 구현
	@Override
	public int resumeInsert(ResumeVO rvo) {
		return session.insert("resumeInsert", rvo);
	}

	// 이력서 수
	public int resumeCount(int m_num) {
		return session.selectOne("resumeCount", m_num);
	}
	
	public int resumeListCnt(ResumeVO rvo) {
		return (Integer)session.selectOne("resumeListCnt");
	}
}
