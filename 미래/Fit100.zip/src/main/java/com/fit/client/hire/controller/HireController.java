package com.fit.client.hire.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fit.client.hire.service.HireService;
import com.fit.client.hire.vo.HireVO;
import com.fit.client.login.vo.LoginVO;
import com.fit.client.member.service.MemberService;
import com.fit.client.member.vo.MemberVO;
import com.fit.client.resume.service.ResumeService;
import com.fit.client.resume.vo.ResumeVO;
import com.fit.common.page.Paging;

@Controller
@RequestMapping(value = "/hire")
public class HireController {
	Logger logger = Logger.getLogger(HireController.class);

	@Autowired
	private HireService hireService;
	@Autowired
	private MemberService memberService;
	@Autowired
	private ResumeService resumeService;

	// 채용공고 리스트
	@RequestMapping(value = "/hireList.do", method = RequestMethod.GET)
	public String hireList(@ModelAttribute HireVO hvo, Model model) {

		Paging.setPage(hvo);

		int total = hireService.hireListCnt(hvo);

		List<HireVO> hireList = hireService.hireList(hvo);
		model.addAttribute("hireList", hireList);
		model.addAttribute("data", hvo);
		model.addAttribute("total", total);
		return "hire/hireList";
	}

	// 진행중인 채용공고 리스트
	@RequestMapping(value = "/hireLiveList.do", method = RequestMethod.GET)
	public String hireLiveList(@ModelAttribute HireVO hvo, Model model) {

		List<HireVO> hireLiveList = hireService.hireLiveList();
		model.addAttribute("hireLiveList", hireLiveList);
		model.addAttribute("data", hvo);
		return "hire/hireLiveList";
	}

	// 마감된 채용공고 리스트
	@RequestMapping(value = "/hireDeadList.do", method = RequestMethod.GET)
	public String hireDeadList(@ModelAttribute HireVO hvo, Model model) {

		List<HireVO> hireDeadList = hireService.hireLiveList();
		model.addAttribute("hireDeadList", hireDeadList);
		model.addAttribute("data", hvo);
		return "hire/hireDeadList";
	}

	// 채용공고 상세보기
	@RequestMapping(value = "/hireDetail.do", method = RequestMethod.GET)
	public String hireDetail(@ModelAttribute HireVO hvo, Model model, HttpSession session) {
		logger.info("hireDetail 호출 성공");
		HireVO detail = new HireVO();
		detail = hireService.hireDetail(hvo);
		if (detail != null && (!detail.equals(""))) {
			detail.setH_hiredetail(detail.getH_hiredetail().toString().replaceAll("\n", "<br>"));
		}

		LoginVO login = (LoginVO) session.getAttribute("login");
		MemberVO mvo = new MemberVO();
		mvo = memberService.memberSelect(login.getUserId());

		if (mvo != null) {
			List<ResumeVO> myResume = resumeService.myResumeList(mvo.getM_num());
			model.addAttribute("myResume", myResume);
		}
		;

		model.addAttribute("mvo", mvo);
		model.addAttribute("detail", detail);
		return "hire/hireDetail";
	}

	/**************************************************************
	 * 채용공고 등록 폼 출력하기
	 **************************************************************/
	@RequestMapping(value = "/hireForm.do")
	public String hireForm() {
		logger.info("hireForm 호출 성공");
		return "hire/hireForm";
	}

	/**************************************************************
	 * 채용공고 등록하기
	 **************************************************************/
	@RequestMapping(value = "/hireInsert.do", method = RequestMethod.POST)
	public String hireInsert(@ModelAttribute HireVO hvo, Model model) {
		logger.info("hireInsert 호출 성공");
		int result = 0;
		String url = "";
		result = hireService.hireInsert(hvo);
		if (result == 1) {
			url = "/hire/hireList.do";
		} else {
			url = "/hire/hireForm.do";
		}
		return "redirect:" + url;
	}

}
