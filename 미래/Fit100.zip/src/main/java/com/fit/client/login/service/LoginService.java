package com.fit.client.login.service;

import com.fit.client.login.vo.LoginVO;

public interface LoginService {
	public LoginVO userIdSelect(String userId);
	public LoginVO companyUserIdSelect(String userId);
	public LoginVO loginSelect(String userId, String userPw);
	public LoginVO companyLoginSelect(String userId, String userPw);
	public int loginHistoryInsert(LoginVO lvo) ;
	public int companyLoginHistoryInsert(LoginVO lvo);
	public int loginHistoryUpdate(LoginVO lvo);
	public LoginVO loginHistorySelect(String userId); 
}
