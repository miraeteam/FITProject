package com.fit.client.hire.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fit.client.hire.vo.HireVO;

@Repository
@Transactional
public class HireDAOImpl implements HireDAO {
	@Autowired
	private SqlSession session;

	@Override
	public List<HireVO> hireList(HireVO hvo) {
		return session.selectList("hireList", hvo);
	}

	public HireVO hireDetail(HireVO hvo) {
		return (HireVO) session.selectOne("hireDetail", hvo);
	}

	public int hireInsert(HireVO hvo) {
		return session.insert("hireInsert", hvo);
	}

	public List<HireVO> myHire(int c_num) {
		return session.selectList("myHire");
	}

	public int hireListCnt(HireVO hvo) {
		return session.selectOne("hireListCnt");
	}

	public List<HireVO> hireLiveList() {
		return session.selectList("hireLiveList");
	}

	@Override
	public List<HireVO> hireDeadList() {
		return session.selectList("hireDeadList");
	}

	@Override
	public int hireLiveListCount(int c_num) {
		return session.selectOne("hireLiveListCount", c_num);
	}

	@Override
	public int hireDeadListCount(int c_num) {
		return session.selectOne("hireDeadListCount", c_num);
	}
}
