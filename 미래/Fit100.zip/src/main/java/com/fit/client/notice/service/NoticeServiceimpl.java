package com.fit.client.notice.service;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fit.client.notice.dao.NoticeDAO;
import com.fit.client.notice.vo.NoticeVO;
import com.fit.client.qna.vo.QnaVO;

@Service
@Transactional
public class NoticeServiceimpl implements NoticeService {
	Logger logger = Logger.getLogger(NoticeServiceimpl.class);
	@Autowired
	private SqlSession session;
	@Autowired
	private NoticeDAO noticeDAO;

	public List<NoticeVO> noticeList() {
		List<NoticeVO> myList = null;
		myList = noticeDAO.noticeList();
		return myList;
	}
	// 글상세 구현
		@Override
		public NoticeVO noticeDetail(NoticeVO nvo) {
			return (NoticeVO) session.selectOne("noticeDetail", nvo);
		}
		public int noticeListCnt(NoticeVO nvo) {
			return noticeDAO.noticeListCnt(nvo);
		}
}
