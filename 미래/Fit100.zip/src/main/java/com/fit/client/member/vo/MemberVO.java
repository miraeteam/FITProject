package com.fit.client.member.vo;

import java.sql.Timestamp;

import com.fit.client.login.vo.LoginVO;

public class MemberVO extends LoginVO {
	private String key;
	private String oldUserPw;
	private int m_num;
	private String m_year;
	private String email;
	private String m_phone;
	private String address;
	private String m_status;
	private String m_gender;
	private Timestamp m_joindate;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Timestamp getM_joindate() {
		return m_joindate;
	}

	public void setM_joindate(Timestamp m_joindate) {
		this.m_joindate = m_joindate;
	}

	public int getM_num() {
		return m_num;
	}

	public void setM_num(int m_num) {
		this.m_num = m_num;
	}

	public String getOldUserPw() {
		return oldUserPw;
	}

	public void setOldUserPw(String oldUserPw) {
		this.oldUserPw = oldUserPw;
	}

	public String getM_year() {
		return m_year;
	}

	public void setM_year(String m_year) {
		this.m_year = m_year;
	}

	public String getM_phone() {
		return m_phone;
	}

	public void setM_phone(String m_phone) {
		this.m_phone = m_phone;
	}

	public String getM_status() {
		return m_status;
	}

	public void setM_status(String m_status) {
		this.m_status = m_status;
	}

	public String getM_gender() {
		return m_gender;
	}

	public void setM_gender(String m_gender) {
		this.m_gender = m_gender;
	}

	@Override
	public String toString() {
		return "MemberVO [oldUserPw=" + oldUserPw + ", m_num=" + m_num + ", userId=" + ", m_year=" + m_year + ", email="
				+ email + ", m_phone=" + m_phone + ", address=" + address + ", m_status=" + m_status + ", m_gender="
				+ m_gender + ", m_joindate=" + m_joindate + "]";
	}

}
