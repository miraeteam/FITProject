package com.fit.client.qna.service;

import java.util.List;

import com.fit.client.qna.vo.QnaVO;

public interface QnaService {
	public List<QnaVO>qnaList();
	public int insertQna(QnaVO bvo);
	public QnaVO qnaDetail(QnaVO qnvo);
	public int qnaListCnt(QnaVO qnvo);
	
}
