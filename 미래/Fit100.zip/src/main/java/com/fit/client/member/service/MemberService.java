package com.fit.client.member.service;

import java.util.List;

import com.fit.client.member.vo.CompanyVO;
import com.fit.client.member.vo.MemberVO;
import com.fit.common.vo.ComeOnCompanyVO;
import com.fit.common.vo.EmailVO;
import com.fit.common.vo.InterviewApplyVO;
import com.fit.common.vo.OnlineVO;

public interface MemberService {
	public int userIdConfirm(String userId);

	public MemberVO memberSelect(String userId);

	public int memberInsert(MemberVO mvo);

	public boolean memberUpdate(MemberVO mvo);

	public int memberDelete(String userId);

	public int companyInsert(CompanyVO cvo);

	public boolean companyUpdate(CompanyVO cvo);

	public CompanyVO companySelect(String userId);

	public int emailInsert(EmailVO evo);

	public int onlineInsert(OnlineVO ovo);

	public int comeOnInsert(ComeOnCompanyVO covo);

	public int interviewApply(InterviewApplyVO ivo);

	public List<ComeOnCompanyVO> comeOnCompanyList(int m_num);

	public List<InterviewApplyVO> interviewList(int m_num);

	public List<OnlineVO> onlineList(int m_num);

	public List<EmailVO> emailList(int m_num);

	public int onlineCount(int m_num);

	public int emailCount(int m_num);

	public int comeOnCompanyCount(int m_num);

	public int interviewApplyCount(int m_num);

	public int pwdConfirm(MemberVO mvo);

	public List<ComeOnCompanyVO> comeOnList(int c_num);

	public List<OnlineVO> onlineList_company(int c_num);

	public List<InterviewApplyVO> interviewApply_company(int c_num);

	public int online_companyCount(int c_num);

	public int comeOnCount(int c_num);

	public int interviewApply_companyCount(int c_num);

}
