package com.fit.client.resume.vo;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

import com.fit.client.member.vo.MemberVO;

public class ResumeVO extends MemberVO {
	private int R_num;
	private String R_level;
	private String R_career;
	private String R_detail;
	private String R_choice;
	private String R_major;
	private String R_workType;
	private String R_salary;
	private String R_location;
	private String R_title;
	private String R_selfInfo;
	private String R_profile;
	private Timestamp R_joinDate;
	private String R_resumeFile;
	private MultipartFile file;
	private int R_resumeCount;
	
	
	private String page;	//페이지 번호
	private String pageSize;	//페이지에 보여주는 줄수
	private String start_row;	//시작 레코드 번호
	private String end_row;		//종료 레코드 번호
	//조건 검색 시 사용할 필드
	private String search = "";
	private String keyword= "";
	//제목 클릭시 정렬을 위한 필드
	private String order_by;
	private String order_sc;
	
	
	public String getSearch() {
		return search;
	}

	public void setSearch(String search) {
		this.search = search;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getOrder_by() {
		return order_by;
	}

	public void setOrder_by(String order_by) {
		this.order_by = order_by;
	}

	public String getOrder_sc() {
		return order_sc;
	}

	public void setOrder_sc(String order_sc) {
		this.order_sc = order_sc;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getPageSize() {
		return pageSize;
	}

	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}

	public String getStart_row() {
		return start_row;
	}

	public void setStart_row(String start_row) {
		this.start_row = start_row;
	}

	public String getEnd_row() {
		return end_row;
	}

	public void setEnd_row(String end_row) {
		this.end_row = end_row;
	}

	public int getR_resumeCount() {
		return R_resumeCount;
	}

	public void setR_resumeCount(int r_resumeCount) {
		R_resumeCount = r_resumeCount;
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public Timestamp getR_joinDate() {
		return R_joinDate;
	}

	public void setR_joinDate(Timestamp r_joinDate) {
		R_joinDate = r_joinDate;
	}

	public String getR_resumeFile() {
		return R_resumeFile;
	}

	public void setR_resumeFile(String r_resumeFile) {
		R_resumeFile = r_resumeFile;
	}

	public int getR_num() {
		return R_num;
	}

	public void setR_num(int r_num) {
		R_num = r_num;
	}

	public String getR_level() {
		return R_level;
	}

	public void setR_level(String r_level) {
		R_level = r_level;
	}

	public String getR_career() {
		return R_career;
	}

	public void setR_career(String r_career) {
		R_career = r_career;
	}

	public String getR_detail() {
		return R_detail;
	}

	public void setR_detail(String r_detail) {
		R_detail = r_detail;
	}

	public String getR_choice() {
		return R_choice;
	}

	public void setR_choice(String r_choice) {
		R_choice = r_choice;
	}

	public String getR_major() {
		return R_major;
	}

	public void setR_major(String r_major) {
		R_major = r_major;
	}

	public String getR_workType() {
		return R_workType;
	}

	public void setR_workType(String r_workType) {
		R_workType = r_workType;
	}

	public String getR_salary() {
		return R_salary;
	}

	public void setR_salary(String r_salary) {
		R_salary = r_salary;
	}

	public String getR_location() {
		return R_location;
	}

	public void setR_location(String r_location) {
		R_location = r_location;
	}

	public String getR_title() {
		return R_title;
	}

	public void setR_title(String r_title) {
		R_title = r_title;
	}

	public String getR_selfInfo() {
		return R_selfInfo;
	}

	public void setR_selfInfo(String r_selfInfo) {
		R_selfInfo = r_selfInfo;
	}

	public String getR_profile() {
		return R_profile;
	}

	public void setR_profile(String r_profile) {
		R_profile = r_profile;
	}

	@Override
	public String toString() {
		return "ResumeVO [R_num=" + R_num + ", R_level=" + R_level + ", R_career=" + R_career + ", R_detail=" + R_detail
				+ ", R_choice=" + R_choice + ", R_major=" + R_major + ", R_workType=" + R_workType + ", R_salary="
				+ R_salary + ", R_location=" + R_location + ", R_title=" + R_title + ", R_selfInfo=" + R_selfInfo
				+ ", R_profile=" + R_profile + "]";
	}

	public String getPage() {
		return page;
		
	}
}
