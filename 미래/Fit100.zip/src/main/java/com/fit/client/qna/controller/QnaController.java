package com.fit.client.qna.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fit.admin.reple.service.AdminRepleService;
import com.fit.admin.reple.vo.RepleVO;
import com.fit.client.qna.service.QnaService;
import com.fit.client.qna.vo.QnaVO;
import com.fit.common.page.Paging;

@Controller
@RequestMapping(value = "/qna")
public class QnaController {
	Logger logger = Logger.getLogger(QnaController.class);

	@Autowired
	private QnaService qnaService;

	@Autowired
	private AdminRepleService adminRepleService;

	/**************************************************************
	 * 리스트보기
	 **************************************************************/
	@RequestMapping(value = "/qnaList.do", method = RequestMethod.GET)
	public String qnaList(@ModelAttribute QnaVO rvo, Model model) {
		logger.info("고객문의 츨력");

		Paging.setPage(rvo);

		int total = qnaService.qnaListCnt(rvo);

		List<QnaVO> qnaList = qnaService.qnaList();
		model.addAttribute("qnaList", qnaList);
		model.addAttribute("data", rvo);
		model.addAttribute("total", total);
		return "qna/qnaList";
	}

	/**************************************************************
	 * 글쓰기 폼 출력하기
	 **************************************************************/
	@RequestMapping(value = "/writeQna.do")
	public String writeForm() {
		logger.info("writeForm 출력");
		return "qna/writeQna";
	}

	/**************************************************************
	 * 글쓰기 구현하기
	 **************************************************************/
	@RequestMapping(value = "/insertQna.do", method = RequestMethod.POST)
	public String QnaInsert(@ModelAttribute QnaVO qvo, Model model) throws IllegalStateException, IOException {
		logger.info("목록추가");
		int result = 0;
		String url = "";

		result = qnaService.insertQna(qvo);
		if (result == 1) {
			url = "/qna/qnaList.do";
		} else {
			url = "/qna/writeQna.do";
		}

		return "redirect:" + url;

	}

	/* 고객문의 상세보기 */
	@RequestMapping(value = "/qnaDetail.do", method = RequestMethod.GET)
	public String qnaDetail(@ModelAttribute RepleVO revo, @ModelAttribute QnaVO qnvo, Model model,
			HttpSession session) {
		logger.info("qnaDetail �샇異� �꽦怨�");
		QnaVO detail = new QnaVO();

		detail = qnaService.qnaDetail(qnvo);
		model.addAttribute("qdetail", detail);

		session.setAttribute("qdetail", detail);

		RepleVO detailre = new RepleVO();
		detailre = adminRepleService.repleDetail(revo);

		model.addAttribute("detailre", detailre);

		if (detail != null && (!detail.equals(""))) {
			detail.setQ_title(detail.getQ_title().toString().replaceAll("\n", "<br>"));
		}
		if (detailre != null && (!detailre.equals(""))) {
			detailre.setRe_content(detailre.getRe_content().toString().replaceAll("\n", "<br>"));
		}

		return "qna/qnaDetail";
	}

	/*	*//**************************************************************
			 * 湲� �긽�꽭蹂닿린 援ы쁽
			 **************************************************************//*
																			 * @RequestMapping(value =
																			 * "/boardDetail.do", method =
																			 * RequestMethod.GET) public String
																			 * boardDetail(@ModelAttribute QnaVO pvo,
																			 * Model model) {
																			 * logger.info("boardDetail �샇異� �꽦怨�");
																			 * logger.info("b_num = " + pvo.getQ_num());
																			 * QnaVO detail = new QnaVO(); detail =
																			 * QnaService.boardDetail(pvo); if (detail
																			 * != null && (!detail.equals(""))) {
																			 * detail.setQ_content(detail.getQ_content()
																			 * .toString().replaceAll("\n", "<br>")); }
																			 * model.addAttribute("detail", detail);
																			 * return "board/boardDetail"; }
																			 */

}
