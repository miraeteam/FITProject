package com.fit.client.notice.vo;

import java.util.Date;

import com.fit.client.login.vo.LoginVO;

public class NoticeVO extends LoginVO {
	private int N_num;
	private String N_title;
	private String N_content;
	private String userId;
	private Date N_writedate;

	private String page; // 페이지 번호
	private String pageSize; // 페이지에 보여주는 줄수
	private String start_row; // 시작 레코드 번호
	private String end_row; // 종료 레코드 번호
	// 조건 검색 시 사용할 필드
	private String search = "";
	private String keyword = "";
	// 제목 클릭시 정렬을 위한 필드
	private String order_by;
	private String order_sc;

	
	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getPageSize() {
		return pageSize;
	}

	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}

	public String getStart_row() {
		return start_row;
	}

	public void setStart_row(String start_row) {
		this.start_row = start_row;
	}

	public String getEnd_row() {
		return end_row;
	}

	public void setEnd_row(String end_row) {
		this.end_row = end_row;
	}

	public String getSearch() {
		return search;
	}

	public void setSearch(String search) {
		this.search = search;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getOrder_by() {
		return order_by;
	}

	public void setOrder_by(String order_by) {
		this.order_by = order_by;
	}

	public String getOrder_sc() {
		return order_sc;
	}

	public void setOrder_sc(String order_sc) {
		this.order_sc = order_sc;
	}

	public int getN_num() {
		return N_num;
	}

	public void setN_num(int n_num) {
		N_num = n_num;
	}

	public String getN_title() {
		return N_title;
	}

	public void setN_title(String n_title) {
		N_title = n_title;
	}

	public String getN_content() {
		return N_content;
	}

	public void setN_content(String n_content) {
		N_content = n_content;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Date getN_writedate() {
		return N_writedate;
	}

	public void setN_writedate(Date n_writedate) {
		N_writedate = n_writedate;
	}

	@Override
	public String toString() {
		return "NoticeVO [N_num=" + N_num + ", N_title=" + N_title + ", N_content=" + N_content + ", userId=" + userId
				+ ", N_writedate=" + N_writedate + "]";
	}

}
