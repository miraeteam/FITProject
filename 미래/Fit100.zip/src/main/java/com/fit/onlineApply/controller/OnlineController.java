package com.fit.onlineApply.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.fit.client.hire.service.HireService;
import com.fit.client.hire.vo.HireVO;
import com.fit.client.login.vo.LoginVO;
import com.fit.client.member.service.MemberService;
import com.fit.client.member.vo.MemberVO;
import com.fit.client.resume.service.ResumeService;
import com.fit.client.resume.vo.ResumeVO;
import com.fit.common.file.FileUploadUtil;
import com.fit.common.vo.ComeOnCompanyVO;
import com.fit.common.vo.EmailVO;
import com.fit.common.vo.InterviewApplyVO;
import com.fit.common.vo.OnlineVO;
import com.fit.email.vo.Email;

@Controller
@RequestMapping(value = "/online")
public class OnlineController {
	Logger logger = Logger.getLogger(OnlineController.class);

	@Autowired
	private EmailSender emailSender;
	@Autowired
	private HireService hireService;
	@Autowired
	private MemberService memberService;
	@Autowired
	private ResumeService resumeService;

	@RequestMapping(value = "/apply.do", method = RequestMethod.POST)
	public ModelAndView sendEmailAction(@ModelAttribute OnlineVO ovo, @ModelAttribute HireVO hvo, HttpSession session,
			HttpServletRequest request) throws Exception {
		logger.info("온라인지원 호출 성공");

		if (ovo.getFile() != null) {
			String b_file = FileUploadUtil.fileUpload(ovo.getFile(), request, "ovo");
			ovo.setO_file(b_file);
		}

		ModelAndView mav = new ModelAndView();
		HireVO detail = new HireVO();
		detail = hireService.hireDetail(hvo);

		System.out.println(detail);

		int result = 0;
		result = memberService.onlineInsert(ovo);

		System.out.println(ovo);

		mav.addObject("detail", detail);
		if (result == 1) {
			mav.setViewName("hire/hireDetail");
		} else {
			mav.setViewName("hire/hireList");
		}

		return mav;
	}

	@RequestMapping(value = "/comeOn.do", method = RequestMethod.POST)
	public ModelAndView comeOn(@ModelAttribute ComeOnCompanyVO covo, @ModelAttribute ResumeVO rvo, HttpSession session,
			HttpServletRequest request) throws Exception {
		logger.info("입사요청 호출 성공");

		ModelAndView mav = new ModelAndView();
		ResumeVO detail = new ResumeVO();
		detail = resumeService.resumeDetail(rvo);

		System.out.println(covo);
		int result = 0;
		result = memberService.comeOnInsert(covo);

		mav.addObject("detail", detail);
		if (result == 1) {
			mav.setViewName("resume/resumeDetail");
		} else {
			mav.setViewName("resume/resumeList");
		}

		return mav;
	}

	@RequestMapping(value = "/interview.do", method = RequestMethod.POST)
	public ModelAndView interview(@ModelAttribute InterviewApplyVO ivo, @ModelAttribute ResumeVO rvo,
			HttpSession session, HttpServletRequest request) throws Exception {
		logger.info("입사요청 호출 성공");

		ModelAndView mav = new ModelAndView();
		ResumeVO detail = new ResumeVO();
		detail = resumeService.resumeDetail(rvo);

		System.out.println(ivo);
		int result = 0;
		result = memberService.interviewApply(ivo);

		int c_num = (int) session.getAttribute("companyNum");

		List<HireVO> myHire = hireService.myHire(c_num);

		mav.addObject("myHire", myHire);
		mav.addObject("detail", detail);
		if (result == 1) {
			mav.setViewName("resume/resumeDetail");
		} else {
			mav.setViewName("resume/resumeList");
		}

		return mav;
	}

	@RequestMapping(value = "/send.do", method = RequestMethod.POST)
	public ModelAndView sendEmailAction(@ModelAttribute EmailVO evo, @ModelAttribute HireVO hvo,
			@ModelAttribute MemberVO mvo, HttpSession session, HttpServletRequest request) throws Exception {
		logger.info("이메일 호출 성공");

		EmailVO ev = new EmailVO();

		if (ev.getFile() != null) {
			String b_file = FileUploadUtil.fileUpload(ev.getFile(), request, "ev");
			ev.setE_file(b_file);
		}

		ModelAndView mav = new ModelAndView();
		HireVO detail = new HireVO();
		detail = hireService.hireDetail(hvo);

		int result = 0;
		result = memberService.emailInsert(evo);

		Email email = new Email();

		String reciver = detail.getEmail();
		String subject = "입사지원 신청입니다.";
		String content = "www.fit.com";

		email.setReciver(reciver);
		email.setSubject(subject);
		email.setContent(content);

		emailSender.SendEmail(email);

		mav.addObject("detail", detail);
		if (result == 1) {
			mav.setViewName("hire/hireDetail");
		} else {
			mav.setViewName("hire/hireList");
		}

		return mav;

	}

}
