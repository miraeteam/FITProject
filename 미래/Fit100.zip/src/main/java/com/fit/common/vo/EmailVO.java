package com.fit.common.vo;

import java.sql.Timestamp;

import org.springframework.web.multipart.MultipartFile;

import com.fit.client.hire.vo.HireVO;

public class EmailVO extends HireVO {
	private int e_num;
	private String e_title;
	private String e_resume;
	private String e_file = ""; // 실제서버에 저장한 파일명
	private String e_phone;
	private String e_email;
	private Timestamp e_date;
	private int m_num;
	private int c_num;
	private String member;
	private String company;
	private String c_companyName;

	public String getC_companyName() {
		return c_companyName;
	}

	public void setC_companyName(String c_companyName) {
		this.c_companyName = c_companyName;
	}

	public String getMember() {
		return member;
	}

	public void setMember(String member) {
		this.member = member;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public int getC_num() {
		return c_num;
	}

	public void setC_num(int c_num) {
		this.c_num = c_num;
	}

	public int getM_num() {
		return m_num;
	}

	public void setM_num(int m_num) {
		this.m_num = m_num;
	}

	private MultipartFile file; // 첨부파일

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public int getE_num() {
		return e_num;
	}

	public void setE_num(int e_num) {
		this.e_num = e_num;
	}

	public String getE_title() {
		return e_title;
	}

	public void setE_title(String e_title) {
		this.e_title = e_title;
	}

	public String getE_resume() {
		return e_resume;
	}

	public void setE_resume(String e_resume) {
		this.e_resume = e_resume;
	}

	public String getE_file() {
		return e_file;
	}

	public void setE_file(String e_file) {
		this.e_file = e_file;
	}

	public String getE_phone() {
		return e_phone;
	}

	public void setE_phone(String e_phone) {
		this.e_phone = e_phone;
	}

	public String getE_email() {
		return e_email;
	}

	public void setE_email(String e_email) {
		this.e_email = e_email;
	}

	public Timestamp getE_date() {
		return e_date;
	}

	public void setE_date(Timestamp e_date) {
		this.e_date = e_date;
	}

	@Override
	public String toString() {
		return "EmailVO [e_num=" + e_num + ", e_title=" + e_title + ", e_resume=" + e_resume + ", e_file=" + e_file
				+ ", e_phone=" + e_phone + ", e_email=" + e_email + ", e_date=" + e_date + "]";
	}

}
