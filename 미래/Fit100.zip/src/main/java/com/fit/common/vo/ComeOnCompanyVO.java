package com.fit.common.vo;

import java.sql.Timestamp;

import com.fit.client.member.vo.MemberVO;

public class ComeOnCompanyVO extends MemberVO {
	private int come_num;
	private String come_hire;
	private String come_name;
	private String come_phone;
	private String come_email;
	private String come_msg;
	private Timestamp come_date;
	private int c_num;
	private String r_title;
	private String member;
	private String company;
	private String c_companyName;

	public String getMember() {
		return member;
	}

	public void setMember(String member) {
		this.member = member;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getC_companyName() {
		return c_companyName;
	}

	public void setC_companyName(String c_companyName) {
		this.c_companyName = c_companyName;
	}

	public int getCome_num() {
		return come_num;
	}

	public void setCome_num(int come_num) {
		this.come_num = come_num;
	}

	public String getCome_hire() {
		return come_hire;
	}

	public void setCome_hire(String come_hire) {
		this.come_hire = come_hire;
	}

	public String getCome_name() {
		return come_name;
	}

	public void setCome_name(String come_name) {
		this.come_name = come_name;
	}

	public String getCome_phone() {
		return come_phone;
	}

	public void setCome_phone(String come_phone) {
		this.come_phone = come_phone;
	}

	public String getCome_email() {
		return come_email;
	}

	public void setCome_email(String come_email) {
		this.come_email = come_email;
	}

	public String getCome_msg() {
		return come_msg;
	}

	public void setCome_msg(String come_msg) {
		this.come_msg = come_msg;
	}

	public Timestamp getCome_date() {
		return come_date;
	}

	public void setCome_date(Timestamp come_date) {
		this.come_date = come_date;
	}

	public int getC_num() {
		return c_num;
	}

	public void setC_num(int c_num) {
		this.c_num = c_num;
	}

	public String getR_title() {
		return r_title;
	}

	public void setR_title(String r_title) {
		this.r_title = r_title;
	}

	@Override
	public String toString() {
		return "ComeOnCompany [come_num=" + come_num + ", come_hire=" + come_hire + ", come_name=" + come_name
				+ ", come_phone=" + come_phone + ", come_email=" + come_email + ", come_msg=" + come_msg
				+ ", come_date=" + come_date + "]";
	}

}
