package com.fit.common.page;

import com.fit.client.hire.vo.HireVO;
import com.fit.client.notice.vo.NoticeVO;
import com.fit.client.qna.vo.QnaVO;
import com.fit.client.resume.vo.ResumeVO;
import com.fit.common.util.Util;

public class Paging {
	/**
	* 페이징을 위한 설정 작업
	* @param cvo
	*/
	public static void setPage(ResumeVO cvo) {
		int page = Util.nvl(cvo.getPage(), 1);
		int pageSize = Util.nvl(cvo.getPageSize(), 10);
		
		if(cvo.getPage()==null) cvo.setPage(page+"");
		if(cvo.getPageSize()==null) cvo.setPageSize(pageSize+"");
		
		int start_row = (page-1)*pageSize +1;
		int end_row = (page-1)*pageSize+pageSize;
		
		cvo.setStart_row(start_row+"");
		cvo.setEnd_row(end_row+"");
	}
	public static void setPage(HireVO hvo) {
		int page = Util.nvl(hvo.getPage(), 1);
		int pageSize = Util.nvl(hvo.getPageSize(), 10);
		
		if(hvo.getPage()==null) hvo.setPage(page+"");
		if(hvo.getPageSize()==null) hvo.setPageSize(pageSize+"");
		
		int start_row = (page-1)*pageSize +1;
		int end_row = (page-1)*pageSize+pageSize;
		
		hvo.setStart_row(start_row+"");
		hvo.setEnd_row(end_row+"");
	}
	public static void setPage(QnaVO qvo) {
		int page = Util.nvl(qvo.getPage(), 1);
		int pageSize = Util.nvl(qvo.getPageSize(), 10);
		
		if(qvo.getPage()==null) qvo.setPage(page+"");
		if(qvo.getPageSize()==null) qvo.setPageSize(pageSize+"");
		
		int start_row = (page-1)*pageSize +1;
		int end_row = (page-1)*pageSize+pageSize;
		
		qvo.setStart_row(start_row+"");
		qvo.setEnd_row(end_row+"");
	}
	public static void setPage(NoticeVO nvo) {
		int page = Util.nvl(nvo.getPage(), 1);
		int pageSize = Util.nvl(nvo.getPageSize(), 10);
		
		if(nvo.getPage()==null) nvo.setPage(page+"");
		if(nvo.getPageSize()==null) nvo.setPageSize(pageSize+"");
		
		int start_row = (page-1)*pageSize +1;
		int end_row = (page-1)*pageSize+pageSize;
		
		nvo.setStart_row(start_row+"");
		nvo.setEnd_row(end_row+"");
	}
}
