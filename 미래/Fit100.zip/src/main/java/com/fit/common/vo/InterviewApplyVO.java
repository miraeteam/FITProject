package com.fit.common.vo;

import java.sql.Timestamp;

import com.fit.client.resume.vo.ResumeVO;

public class InterviewApplyVO extends ResumeVO {
	private int inter_num;
	private String inter_hire;
	private String inter_name;
	private String inter_phone;
	private String inter_email;
	private String inter_msg;
	private Timestamp inter_date;
	private String m_phone;
	private String userName;
	private int c_num;
	private String member;
	private String company;
	private String c_companyName;

	public String getC_companyName() {
		return c_companyName;
	}

	public void setC_companyName(String c_companyName) {
		this.c_companyName = c_companyName;
	}

	public String getMember() {
		return member;
	}

	public void setMember(String member) {
		this.member = member;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public int getC_num() {
		return c_num;
	}

	public void setC_num(int c_num) {
		this.c_num = c_num;
	}

	public int getInter_num() {
		return inter_num;
	}

	public void setInter_num(int inter_num) {
		this.inter_num = inter_num;
	}

	public String getInter_hire() {
		return inter_hire;
	}

	public void setInter_hire(String inter_hire) {
		this.inter_hire = inter_hire;
	}

	public String getInter_name() {
		return inter_name;
	}

	public void setInter_name(String inter_name) {
		this.inter_name = inter_name;
	}

	public String getInter_phone() {
		return inter_phone;
	}

	public void setInter_phone(String inter_phone) {
		this.inter_phone = inter_phone;
	}

	public String getInter_email() {
		return inter_email;
	}

	public void setInter_email(String inter_email) {
		this.inter_email = inter_email;
	}

	public String getInter_msg() {
		return inter_msg;
	}

	public void setInter_msg(String inter_msg) {
		this.inter_msg = inter_msg;
	}

	public Timestamp getInter_date() {
		return inter_date;
	}

	public void setInter_date(Timestamp inter_date) {
		this.inter_date = inter_date;
	}

	public String getM_phone() {
		return m_phone;
	}

	public void setM_phone(String m_phone) {
		this.m_phone = m_phone;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Override
	public String toString() {
		return "InterviewApplyVO [inter_num=" + inter_num + ", inter_hire=" + inter_hire + ", inter_name=" + inter_name
				+ ", inter_phone=" + inter_phone + ", inter_email=" + inter_email + ", inter_msg=" + inter_msg
				+ ", inter_date=" + inter_date + "]";
	}

}
