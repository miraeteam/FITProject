package com.fit.common.vo;

import java.sql.Timestamp;

import org.springframework.web.multipart.MultipartFile;

import com.fit.client.hire.vo.HireVO;

public class OnlineVO extends HireVO {
	private int o_num;
	private String o_title;
	private String o_resume;
	private String o_file = ""; // 실제서버에 저장한 파일명
	private String o_phone;
	private String o_email;
	private Timestamp o_date;
	private int m_num;
	private String member;
	private String company;
	private String c_companyName;

	public String getMember() {
		return member;
	}

	public void setMember(String member) {
		this.member = member;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getC_companyName() {
		return c_companyName;
	}

	public void setC_companyName(String c_companyName) {
		this.c_companyName = c_companyName;
	}

	public int getM_num() {
		return m_num;
	}

	public void setM_num(int m_num) {
		this.m_num = m_num;
	}

	private MultipartFile file; // 첨부파일

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public int getO_num() {
		return o_num;
	}

	public void setO_num(int o_num) {
		this.o_num = o_num;
	}

	public String getO_title() {
		return o_title;
	}

	public void setO_title(String o_title) {
		this.o_title = o_title;
	}

	public String getO_resume() {
		return o_resume;
	}

	public void setO_resume(String o_resume) {
		this.o_resume = o_resume;
	}

	public String getO_file() {
		return o_file;
	}

	public void setO_file(String o_file) {
		this.o_file = o_file;
	}

	public String getO_phone() {
		return o_phone;
	}

	public void setO_phone(String o_phone) {
		this.o_phone = o_phone;
	}

	public String getO_email() {
		return o_email;
	}

	public void setO_email(String o_email) {
		this.o_email = o_email;
	}

	public Timestamp getO_date() {
		return o_date;
	}

	public void setO_date(Timestamp o_date) {
		this.o_date = o_date;
	}

}
